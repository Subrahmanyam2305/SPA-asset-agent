import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// Import page components
import ExpensesDashboard from './pages/ExpensesDashboard';
import PortfolioDashboard from './pages/PortfolioDashboard';

const AppRoutes = () => {
  return (
    <Router>
      <Routes>
        <Route path="/expenses" element={<ExpensesDashboard />} />
        <Route path="/portfolio" element={<PortfolioDashboard />} />
        <Route path="/" element={<ExpensesDashboard />} />
      </Routes>
    </Router>
  );
};

export default AppRoutes;