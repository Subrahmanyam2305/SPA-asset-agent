import React, { useState, useEffect } from 'react';
import aiAnalysisService from '../../services/aiAnalysisService';

const RiskAlerts = ({ portfolioData = [] }) => {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [aiStatus, setAiStatus] = useState('unknown');

  useEffect(() => {
    const fetchAlerts = async () => {
      setLoading(true);
      try {
        // Check AI service health
        const health = await aiAnalysisService.checkHealth();
        setAiStatus(health.status);

        if (health.status === 'healthy') {
          // Get real-time alerts
          const alertsData = await aiAnalysisService.getPortfolioAlerts();
          setAlerts(alertsData);
        } else {
          // Show fallback alerts
          setAlerts([
            {
              type: 'system',
              message: 'AI risk analysis service is initializing...',
              severity: 'info',
              timestamp: new Date().toISOString()
            }
          ]);
        }
      } catch (error) {
        console.error('Failed to fetch alerts:', error);
        setAlerts([
          {
            type: 'error',
            message: 'Unable to connect to AI analysis service',
            severity: 'warning',
            timestamp: new Date().toISOString()
          }
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchAlerts();
    
    // Refresh alerts every 30 seconds
    const interval = setInterval(fetchAlerts, 30000);
    return () => clearInterval(interval);
  }, [portfolioData]);

  const getSeverityColor = (severity) => {
    const colors = {
      'high': 'bg-[#ff0004]',
      'medium': 'bg-[#ffe100]',
      'low': 'bg-[#00d87a]',
      'info': 'bg-[#00abc9]',
      'warning': 'bg-[#ffe100]',
      'error': 'bg-[#ff0004]'
    };
    return colors[severity] || 'bg-[#00abc9]';
  };

  const getSeverityIcon = (severity) => {
    const icons = {
      'high': '⚠️',
      'medium': '⚡',
      'low': '✅',
      'info': 'ℹ️',
      'warning': '⚠️',
      'error': '❌'
    };
    return icons[severity] || 'ℹ️';
  };

  if (loading) {
    return (
      <div className="bg-global-6 rounded-[24px] p-4 sm:p-5">
        <div className="flex items-center justify-center h-32">
          <div className="text-global-1 text-sm">Loading AI insights...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-global-6 rounded-[24px] p-4 sm:p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-[16px] sm:text-[18px] font-poppins font-black text-global-1">
          🤖 AI Risk Alerts
        </h3>
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${
            aiStatus === 'healthy' ? 'bg-[#00d87a]' : 
            aiStatus === 'loading' ? 'bg-[#ffe100]' : 
            'bg-[#ff0004]'
          }`}></div>
          <span className="text-xs text-global-4">
            {aiStatus === 'healthy' ? 'Connected' : 
             aiStatus === 'loading' ? 'Connecting' : 
             'Offline'}
          </span>
        </div>
      </div>

      <div className="space-y-3">
        {alerts.length === 0 ? (
          <div className="text-center py-8 text-global-4 text-sm">
            No active alerts
          </div>
        ) : (
          alerts.map((alert, index) => (
            <div 
              key={index}
              className="bg-global-10 rounded-[16px] p-3 border-l-4"
              style={{ borderLeftColor: getSeverityColor(alert.severity).replace('bg-', '') }}
            >
              <div className="flex items-start gap-3">
                <span className="text-lg flex-shrink-0 mt-0.5">
                  {getSeverityIcon(alert.severity)}
                </span>
                <div className="flex-1 min-w-0">
                  <div className="text-[14px] font-poppins font-medium text-global-1 leading-relaxed">
                    {alert.message}
                  </div>
                  {alert.type && (
                    <div className="text-xs text-global-4 mt-1 capitalize">
                      {alert.type} • {new Date(alert.timestamp).toLocaleTimeString()}
                    </div>
                  )}
                </div>
                <div className={`w-2 h-2 rounded-full ${getSeverityColor(alert.severity)} flex-shrink-0 mt-2`}></div>
              </div>
            </div>
          ))
        )}
      </div>

      {alerts.length > 0 && (
        <div className="mt-4 pt-3 border-t border-global-4/20">
          <button className="text-xs text-global-4 hover:text-global-1 transition-colors">
            View all insights →
          </button>
        </div>
      )}
    </div>
  );
};

export default RiskAlerts;