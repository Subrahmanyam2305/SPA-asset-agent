import React, { useState } from 'react';

const ExpenseModal = ({ isOpen, onClose, onSave }) => {
  const [expense, setExpense] = useState({
    title: '',
    amount: '',
    category: 'Food & Drinks',
    date: new Date().toISOString().split('T')[0],
    description: '',
    recurring: false,
    frequency: 'monthly'
  });

  const expenseCategories = [
    'Rent',
    'Food & Drinks', 
    'Shopping',
    'Transportation',
    'Vehicle',
    'Utilities',
    'Healthcare',
    'Entertainment',
    'Education',
    'Insurance',
    'Other'
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
    if (expense.title && expense.amount) {
      onSave({
        ...expense,
        id: Date.now(),
        amount: parseFloat(expense.amount),
        createdAt: new Date().toISOString()
      });
      setExpense({
        title: '',
        amount: '',
        category: 'Food & Drinks',
        date: new Date().toISOString().split('T')[0],
        description: '',
        recurring: false,
        frequency: 'monthly'
      });
      onClose();
    }
  };

  const handleInputChange = (field, value) => {
    setExpense(prev => ({
      ...prev,
      [field]: value
    }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-global-10 rounded-[24px] p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-[20px] font-poppins font-black text-global-1">
            💸 New Expense
          </h2>
          <button
            onClick={onClose}
            className="w-8 h-8 bg-global-6 rounded-full flex items-center justify-center text-global-4 hover:text-global-1 transition-colors"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Expense Title */}
          <div>
            <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
              Expense Title *
            </label>
            <input
              type="text"
              value={expense.title}
              onChange={(e) => handleInputChange('title', e.target.value)}
              className="w-full bg-global-6 border border-global-4/20 rounded-lg px-3 py-2 text-global-1 text-sm focus:outline-none focus:border-global-8"
              placeholder="e.g., Grocery Shopping"
              required
            />
          </div>

          {/* Amount */}
          <div>
            <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
              Amount *
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-global-4">$</span>
              <input
                type="number"
                step="0.01"
                min="0"
                value={expense.amount}
                onChange={(e) => handleInputChange('amount', e.target.value)}
                className="w-full bg-global-6 border border-global-4/20 rounded-lg pl-8 pr-3 py-2 text-global-1 text-sm focus:outline-none focus:border-global-8"
                placeholder="0.00"
                required
              />
            </div>
          </div>

          {/* Category */}
          <div>
            <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
              Category
            </label>
            <select
              value={expense.category}
              onChange={(e) => handleInputChange('category', e.target.value)}
              className="w-full bg-global-6 border border-global-4/20 rounded-lg px-3 py-2 text-global-1 text-sm focus:outline-none focus:border-global-8"
            >
              {expenseCategories.map((category) => (
                <option key={category} value={category}>{category}</option>
              ))}
            </select>
          </div>

          {/* Date */}
          <div>
            <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
              Date
            </label>
            <input
              type="date"
              value={expense.date}
              onChange={(e) => handleInputChange('date', e.target.value)}
              className="w-full bg-global-6 border border-global-4/20 rounded-lg px-3 py-2 text-global-1 text-sm focus:outline-none focus:border-global-8"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
              Description
            </label>
            <textarea
              value={expense.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              className="w-full bg-global-6 border border-global-4/20 rounded-lg px-3 py-2 text-global-1 text-sm focus:outline-none focus:border-global-8 resize-none"
              rows="2"
              placeholder="Optional details about this expense"
            />
          </div>

          {/* Recurring */}
          <div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={expense.recurring}
                onChange={(e) => handleInputChange('recurring', e.target.checked)}
                className="w-4 h-4 text-global-8 bg-global-6 border-global-4 rounded focus:ring-global-8 focus:ring-2"
              />
              <span className="text-sm font-poppins font-medium text-global-1">
                Recurring Expense
              </span>
            </label>
            
            {expense.recurring && (
              <div className="mt-2">
                <select
                  value={expense.frequency}
                  onChange={(e) => handleInputChange('frequency', e.target.value)}
                  className="w-full bg-global-6 border border-global-4/20 rounded-lg px-3 py-2 text-global-1 text-sm focus:outline-none focus:border-global-8"
                >
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                  <option value="quarterly">Quarterly</option>
                  <option value="yearly">Yearly</option>
                </select>
              </div>
            )}
          </div>

          {/* Buttons */}
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 px-4 bg-global-6 text-global-4 rounded-lg text-sm font-medium hover:text-global-1 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-2 px-4 bg-global-8 text-global-1 rounded-lg text-sm font-medium hover:bg-opacity-90 transition-colors"
            >
              Add Expense
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ExpenseModal;