import React, { useState, useEffect } from 'react';
import aiAnalysisService from '../../services/aiAnalysisService';

const AssetAnalysis = ({ asset, onAnalysisComplete }) => {
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    if (asset && !analysis) {
      analyzeAsset();
    }
  }, [asset]);

  const analyzeAsset = async () => {
    if (!asset) return;
    
    setLoading(true);
    try {
      // Convert asset value from string to number
      const numericValue = parseFloat(asset.value.replace(/[$,]/g, ''));
      
      const result = await aiAnalysisService.analyzeAsset(
        asset.name,
        asset.name.toLowerCase(), // Use name as type for simplicity
        numericValue
      );
      
      setAnalysis(result);
      if (onAnalysisComplete) {
        onAnalysisComplete(asset.id, result);
      }
    } catch (error) {
      console.error('Asset analysis failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const getRiskBadgeColor = (riskLevel) => {
    const colors = {
      'high': 'bg-[#ff0004] text-white',
      'medium': 'bg-[#ffe100] text-black',
      'low': 'bg-[#00d87a] text-white',
      'very_low': 'bg-[#00abc9] text-white',
      'absent': 'bg-[#00d87a] text-white'
    };
    return colors[riskLevel] || 'bg-[#ffe100] text-black';
  };

  const getConfidenceBarColor = (confidence) => {
    if (confidence >= 80) return 'bg-[#00d87a]';
    if (confidence >= 60) return 'bg-[#ffe100]';
    return 'bg-[#ff0004]';
  };

  if (loading) {
    return (
      <div className="bg-global-6 rounded-[16px] p-4 animate-pulse">
        <div className="flex items-center gap-3">
          <div className={`w-[40px] h-[40px] ${asset?.color || 'bg-gray-300'} rounded-full`}></div>
          <div className="flex-1">
            <div className="h-4 bg-gray-300 rounded mb-2"></div>
            <div className="h-3 bg-gray-200 rounded w-3/4"></div>
          </div>
          <div className="text-xs text-global-4">Analyzing...</div>
        </div>
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="bg-global-6 rounded-[16px] p-4">
        <div className="flex items-center gap-3">
          <div className={`w-[40px] h-[40px] ${asset?.color || 'bg-gray-300'} rounded-full`}></div>
          <div className="flex-1">
            <div className="text-[14px] font-poppins font-bold text-global-1">
              {asset?.name || 'Unknown Asset'}
            </div>
            <div className="text-xs text-global-4">Click to analyze</div>
          </div>
          <button
            onClick={analyzeAsset}
            className="px-3 py-1 bg-global-8 text-global-1 rounded-lg text-xs hover:bg-opacity-90 transition-colors"
          >
            Analyze
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-global-6 rounded-[16px] p-4">
      <div className="space-y-3">
        {/* Header */}
        <div className="flex items-center gap-3">
          <div className={`w-[40px] h-[40px] ${asset?.color || 'bg-gray-300'} rounded-full flex-shrink-0`}></div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <div className="text-[14px] font-poppins font-bold text-global-1">
                {analysis.asset_name}
              </div>
              <div className={`px-2 py-0.5 rounded-full text-xs font-medium ${getRiskBadgeColor(analysis.risk_assessment.risk_level)}`}>
                {analysis.risk_assessment.risk_level.toUpperCase()}
              </div>
            </div>
            <div className="text-[18px] font-poppins font-light text-global-1">
              {asset?.value}
            </div>
          </div>
          <button 
            onClick={() => setExpanded(!expanded)}
            className="p-1 hover:bg-global-10 rounded transition-colors"
          >
            <span className={`transform transition-transform ${expanded ? 'rotate-180' : ''}`}>
              ⌄
            </span>
          </button>
        </div>

        {/* Confidence Bar */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs text-global-4">
            <span>AI Confidence</span>
            <span>{analysis.risk_assessment.confidence}%</span>
          </div>
          <div className="w-full bg-global-10 rounded-full h-2">
            <div 
              className={`h-full rounded-full transition-all duration-500 ${getConfidenceBarColor(analysis.risk_assessment.confidence)}`}
              style={{ width: `${analysis.risk_assessment.confidence}%` }}
            ></div>
          </div>
        </div>

        {/* Expanded Details */}
        {expanded && (
          <div className="space-y-3 pt-3 border-t border-global-4/20">
            {/* Risk Reasoning */}
            <div>
              <div className="text-xs font-poppins font-bold text-global-1 mb-2">
                📊 Risk Analysis
              </div>
              <div className="text-xs text-global-4 leading-relaxed bg-global-10 rounded-lg p-3">
                {analysis.risk_assessment.reasoning}
              </div>
            </div>

            {/* Recommendations */}
            {analysis.recommendations && analysis.recommendations.length > 0 && (
              <div>
                <div className="text-xs font-poppins font-bold text-global-1 mb-2">
                  💡 AI Recommendations
                </div>
                <div className="space-y-1">
                  {analysis.recommendations.map((rec, index) => (
                    <div key={index} className="text-xs text-global-4 flex items-start gap-2">
                      <span className="flex-shrink-0 mt-0.5">•</span>
                      <span>{rec}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Market Data */}
            {analysis.market_data && (
              <div>
                <div className="text-xs font-poppins font-bold text-global-1 mb-2">
                  📈 Market Data
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-global-10 rounded p-2">
                    <div className="text-global-4">Type</div>
                    <div className="text-global-1 font-medium">{analysis.market_data.asset_type}</div>
                  </div>
                  <div className="bg-global-10 rounded p-2">
                    <div className="text-global-4">Updated</div>
                    <div className="text-global-1 font-medium">
                      {new Date(analysis.market_data.last_updated).toLocaleTimeString()}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Re-analyze Button */}
            <button
              onClick={analyzeAsset}
              className="w-full py-2 bg-global-8 text-global-1 rounded-lg text-xs hover:bg-opacity-90 transition-colors disabled:opacity-50"
              disabled={loading}
            >
              {loading ? 'Re-analyzing...' : '🔄 Re-analyze Asset'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default AssetAnalysis;