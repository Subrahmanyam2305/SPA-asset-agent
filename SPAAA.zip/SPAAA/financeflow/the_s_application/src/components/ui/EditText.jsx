import React from 'react';
import PropTypes from 'prop-types';

const EditText = ({ 
  placeholder = '', 
  value = '', 
  onChange, 
  type = 'text',
  disabled = false,
  rightImage = null,
  leftImage = null,
  className = '',
  ...props 
}) => {
  const baseClasses = 'font-poppins transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-primary-background focus:border-transparent';
  
  const inputClasses = `
    ${baseClasses}
    ${className}
    ${disabled ? 'cursor-not-allowed opacity-50' : ''}
  `?.trim()?.replace(/\s+/g, ' ');

  return (
    <div className="relative flex items-center">
      {leftImage && (
        <img 
          src={leftImage?.src} 
          alt="left icon" 
          className={`absolute left-3 z-10 w-[${leftImage?.width}px] h-[${leftImage?.height}px]`}
        />
      )}
      <input
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        disabled={disabled}
        className={inputClasses}
        {...props}
      />
      {rightImage && (
        <img 
          src={rightImage?.src} 
          alt="right icon" 
          className={`absolute right-3 z-10 w-[${rightImage?.width}px] h-[${rightImage?.height}px] cursor-pointer`}
        />
      )}
    </div>
  );
};

EditText.propTypes = {
  placeholder: PropTypes?.string,
  value: PropTypes?.string,
  onChange: PropTypes?.func,
  type: PropTypes?.string,
  disabled: PropTypes?.bool,
  rightImage: PropTypes?.shape({
    src: PropTypes?.string?.isRequired,
    width: PropTypes?.number,
    height: PropTypes?.number
  }),
  leftImage: PropTypes?.shape({
    src: PropTypes?.string?.isRequired,
    width: PropTypes?.number,
    height: PropTypes?.number
  }),
  className: PropTypes?.string
};

export default EditText;