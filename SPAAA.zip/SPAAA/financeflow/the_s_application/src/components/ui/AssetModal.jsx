import React, { useState } from 'react';

const AssetModal = ({ isOpen, onClose, onSave }) => {
  const [asset, setAsset] = useState({
    name: '',
    category: 'Stocks',
    value: '',
    description: '',
    color: 'bg-[#00abc9]',
    purchaseDate: new Date().toISOString().split('T')[0],
    quantity: '1',
    costBasis: ''
  });

  const assetCategories = [
    'Stocks',
    'Bonds', 
    'Real Estate',
    'Cryptocurrencies',
    'Commodities',
    'Cash & Equivalents',
    'Collectibles',
    'Alternative Investments',
    'Vehicles',
    'Art & Antiques'
  ];

  const colorOptions = [
    { color: 'bg-[#00abc9]', name: 'Blue' },
    { color: 'bg-[#ff0004]', name: 'Red' },
    { color: 'bg-[#ffe100]', name: 'Yellow' },
    { color: 'bg-[#00d87a]', name: 'Green' },
    { color: 'bg-[#c900b2]', name: 'Purple' },
    { color: 'bg-[#4800ff]', name: 'Indigo' },
    { color: 'bg-[#ff6b00]', name: 'Orange' },
    { color: 'bg-[#9c27b0]', name: 'Violet' }
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
    if (asset.name && asset.value) {
      const numericValue = parseFloat(asset.value);
      const costBasis = asset.costBasis ? parseFloat(asset.costBasis) : numericValue;
      const allocation = 0; // Will be calculated when added to portfolio
      
      onSave({
        ...asset,
        id: Date.now(),
        value: `$${numericValue.toLocaleString()}`,
        allocation,
        indicator: numericValue >= costBasis ? 'up' : 'down',
        indicatorColor: numericValue >= costBasis ? 'bg-global-2' : 'bg-[#ff0004]',
        details: asset.description || `${asset.category} investment`,
        createdAt: new Date().toISOString()
      });
      
      setAsset({
        name: '',
        category: 'Stocks',
        value: '',
        description: '',
        color: 'bg-[#00abc9]',
        purchaseDate: new Date().toISOString().split('T')[0],
        quantity: '1',
        costBasis: ''
      });
      onClose();
    }
  };

  const handleInputChange = (field, value) => {
    setAsset(prev => ({
      ...prev,
      [field]: value
    }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-global-10 rounded-[24px] p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-[20px] font-poppins font-black text-global-1">
            📈 New Asset
          </h2>
          <button
            onClick={onClose}
            className="w-8 h-8 bg-global-6 rounded-full flex items-center justify-center text-global-4 hover:text-global-1 transition-colors"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Asset Name */}
          <div>
            <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
              Asset Name *
            </label>
            <input
              type="text"
              value={asset.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              className="w-full bg-global-6 border border-global-4/20 rounded-lg px-3 py-2 text-global-1 text-sm focus:outline-none focus:border-global-8"
              placeholder="e.g., Apple Stock, Bitcoin, Downtown Property"
              required
            />
          </div>

          {/* Category */}
          <div>
            <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
              Category
            </label>
            <select
              value={asset.category}
              onChange={(e) => handleInputChange('category', e.target.value)}
              className="w-full bg-global-6 border border-global-4/20 rounded-lg px-3 py-2 text-global-1 text-sm focus:outline-none focus:border-global-8"
            >
              {assetCategories.map((category) => (
                <option key={category} value={category}>{category}</option>
              ))}
            </select>
          </div>

          {/* Current Value */}
          <div>
            <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
              Current Value *
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-global-4">$</span>
              <input
                type="number"
                step="0.01"
                min="0"
                value={asset.value}
                onChange={(e) => handleInputChange('value', e.target.value)}
                className="w-full bg-global-6 border border-global-4/20 rounded-lg pl-8 pr-3 py-2 text-global-1 text-sm focus:outline-none focus:border-global-8"
                placeholder="0.00"
                required
              />
            </div>
          </div>

          {/* Cost Basis */}
          <div>
            <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
              Purchase Price (Cost Basis)
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-global-4">$</span>
              <input
                type="number"
                step="0.01"
                min="0"
                value={asset.costBasis}
                onChange={(e) => handleInputChange('costBasis', e.target.value)}
                className="w-full bg-global-6 border border-global-4/20 rounded-lg pl-8 pr-3 py-2 text-global-1 text-sm focus:outline-none focus:border-global-8"
                placeholder="Original purchase price"
              />
            </div>
          </div>

          {/* Quantity */}
          <div>
            <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
              Quantity/Shares
            </label>
            <input
              type="number"
              step="0.001"
              min="0"
              value={asset.quantity}
              onChange={(e) => handleInputChange('quantity', e.target.value)}
              className="w-full bg-global-6 border border-global-4/20 rounded-lg px-3 py-2 text-global-1 text-sm focus:outline-none focus:border-global-8"
              placeholder="Number of shares or units"
            />
          </div>

          {/* Purchase Date */}
          <div>
            <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
              Purchase Date
            </label>
            <input
              type="date"
              value={asset.purchaseDate}
              onChange={(e) => handleInputChange('purchaseDate', e.target.value)}
              className="w-full bg-global-6 border border-global-4/20 rounded-lg px-3 py-2 text-global-1 text-sm focus:outline-none focus:border-global-8"
            />
          </div>

          {/* Color Selection */}
          <div>
            <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
              Display Color
            </label>
            <div className="grid grid-cols-4 gap-2">
              {colorOptions.map((option) => (
                <button
                  key={option.color}
                  type="button"
                  onClick={() => handleInputChange('color', option.color)}
                  className={`w-full h-10 ${option.color} rounded-lg border-2 transition-all ${
                    asset.color === option.color ? 'border-global-1 scale-110' : 'border-transparent'
                  }`}
                  title={option.name}
                />
              ))}
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
              Description/Notes
            </label>
            <textarea
              value={asset.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              className="w-full bg-global-6 border border-global-4/20 rounded-lg px-3 py-2 text-global-1 text-sm focus:outline-none focus:border-global-8 resize-none"
              rows="2"
              placeholder="Optional details about this asset"
            />
          </div>

          {/* Buttons */}
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 px-4 bg-global-6 text-global-4 rounded-lg text-sm font-medium hover:text-global-1 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-2 px-4 bg-global-8 text-global-1 rounded-lg text-sm font-medium hover:bg-opacity-90 transition-colors"
            >
              Add Asset
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AssetModal;