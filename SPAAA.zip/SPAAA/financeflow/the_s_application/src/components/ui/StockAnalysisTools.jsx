import React, { useState, useEffect } from 'react';
import aiAnalysisService from '../../services/aiAnalysisService';
import stockAnalysisService from '../../services/stockAnalysisService';

const StockAnalysisTools = ({ onClose }) => {
  const [selectedStock, setSelectedStock] = useState('');
  const [stockSymbol, setStockSymbol] = useState('');
  const [analysisMode, setAnalysisMode] = useState('overview'); // 'overview', 'technical', 'fundamental', 'news'
  const [stockData, setStockData] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [watchlist, setWatchlist] = useState(['AAPL', 'GOOGL', 'MSFT', 'TSLA', 'NVDA', 'AMZN', 'META', 'BRK.B']);
  const [portfolioStocks, setPortfolioStocks] = useState([]);
  const [portfolioLoading, setPortfolioLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('search'); // 'search' or 'portfolio'

  // Load portfolio stocks on component mount
  useEffect(() => {
    loadPortfolioStocks();
  }, []);

  const loadPortfolioStocks = async () => {
    setPortfolioLoading(true);
    try {
      const stocks = await stockAnalysisService.getPortfolioStocks();
      setPortfolioStocks(stocks.map(stock => stockAnalysisService.formatPortfolioStock(stock)));
    } catch (error) {
      console.error('Failed to load portfolio stocks:', error);
    } finally {
      setPortfolioLoading(false);
    }
  };

  const refreshPortfolioStock = async (stockName) => {
    try {
      await stockAnalysisService.refreshStockAnalysis(stockName);
      // Reload portfolio stocks after refresh
      setTimeout(() => {
        loadPortfolioStocks();
      }, 2000); // Wait 2 seconds for analysis to complete
    } catch (error) {
      console.error('Failed to refresh stock:', error);
    }
  };

  // Popular stocks for quick selection
  const popularStocks = [
    { symbol: 'AAPL', name: 'Apple Inc.', sector: 'Technology' },
    { symbol: 'GOOGL', name: 'Alphabet Inc.', sector: 'Technology' },
    { symbol: 'MSFT', name: 'Microsoft Corp.', sector: 'Technology' },
    { symbol: 'TSLA', name: 'Tesla Inc.', sector: 'Automotive' },
    { symbol: 'NVDA', name: 'NVIDIA Corp.', sector: 'Semiconductors' },
    { symbol: 'AMZN', name: 'Amazon.com Inc.', sector: 'E-commerce' },
    { symbol: 'META', name: 'Meta Platforms Inc.', sector: 'Social Media' },
    { symbol: 'JPM', name: 'JPMorgan Chase & Co.', sector: 'Banking' },
    { symbol: 'JNJ', name: 'Johnson & Johnson', sector: 'Healthcare' },
    { symbol: 'V', name: 'Visa Inc.', sector: 'Financial Services' }
  ];

  const analyzeStock = async (symbol) => {
    if (!symbol) return;
    
    setLoading(true);
    try {
      // Mock stock data (in real implementation, would fetch from yfinance or financial API)
      const mockStockData = {
        symbol: symbol,
        price: Math.random() * 200 + 50,
        change: (Math.random() - 0.5) * 10,
        changePercent: (Math.random() - 0.5) * 5,
        volume: Math.floor(Math.random() * 10000000) + 1000000,
        marketCap: Math.floor(Math.random() * 1000) + 100 + 'B',
        pe: Math.random() * 30 + 10,
        dividend: Math.random() * 3,
        beta: Math.random() * 2 + 0.5,
        fiftyTwoWeekHigh: Math.random() * 250 + 100,
        fiftyTwoWeekLow: Math.random() * 100 + 30
      };
      
      setStockData(mockStockData);

      // Use our AI service for stock analysis
      const aiAnalysis = await aiAnalysisService.analyzeAsset(
        `${symbol} Stock`,
        'stock',
        mockStockData.price
      );

      // Generate comprehensive stock analysis
      const comprehensiveAnalysis = {
        ...aiAnalysis,
        technical: {
          trend: mockStockData.change > 0 ? 'Bullish' : 'Bearish',
          support: (mockStockData.price * 0.95).toFixed(2),
          resistance: (mockStockData.price * 1.05).toFixed(2),
          rsi: Math.floor(Math.random() * 100),
          macd: mockStockData.change > 0 ? 'Buy' : 'Sell',
          volume_analysis: mockStockData.volume > 5000000 ? 'High Volume' : 'Normal Volume'
        },
        fundamental: {
          valuation: mockStockData.pe < 20 ? 'Undervalued' : mockStockData.pe > 30 ? 'Overvalued' : 'Fair Value',
          growth_potential: Math.random() > 0.5 ? 'High' : 'Moderate',
          debt_to_equity: (Math.random() * 2).toFixed(2),
          roe: (Math.random() * 25 + 5).toFixed(1) + '%',
          profit_margin: (Math.random() * 30 + 10).toFixed(1) + '%'
        },
        sentiment: {
          analyst_rating: ['Strong Buy', 'Buy', 'Hold', 'Sell'][Math.floor(Math.random() * 4)],
          price_target: (mockStockData.price * (1 + (Math.random() - 0.5) * 0.3)).toFixed(2),
          news_sentiment: Math.random() > 0.5 ? 'Positive' : Math.random() > 0.25 ? 'Neutral' : 'Negative',
          social_sentiment: Math.floor(Math.random() * 100) + '%'
        }
      };

      setAnalysis(comprehensiveAnalysis);
    } catch (error) {
      console.error('Stock analysis failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStockSearch = (e) => {
    e.preventDefault();
    if (stockSymbol.trim()) {
      analyzeStock(stockSymbol.toUpperCase());
    }
  };

  const selectPopularStock = (stock) => {
    setStockSymbol(stock.symbol);
    setSelectedStock(stock);
    analyzeStock(stock.symbol);
  };

  const addToWatchlist = (symbol) => {
    if (!watchlist.includes(symbol)) {
      setWatchlist(prev => [...prev, symbol]);
    }
  };

  const getRiskColor = (riskLevel) => {
    const colors = {
      'high': 'text-[#ff0004]',
      'medium': 'text-[#ffe100]',
      'low': 'text-[#00d87a]',
      'very_low': 'text-[#00abc9]'
    };
    return colors[riskLevel] || 'text-[#ffe100]';
  };

  const getTrendIcon = (trend) => {
    return trend === 'Bullish' ? '📈' : '📉';
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <div className="bg-global-10 rounded-[24px] p-6 w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-[24px] font-poppins font-black text-global-1">
            🤖 AI Stock Analysis Tool
          </h2>
          <button
            onClick={onClose}
            className="w-8 h-8 bg-global-6 rounded-full flex items-center justify-center text-global-4 hover:text-global-1 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="mb-6">
          <div className="flex mb-4 bg-global-6 rounded-lg p-1">
            <button
              onClick={() => setActiveTab('search')}
              className={`flex-1 py-2 px-3 rounded text-sm transition-colors ${
                activeTab === 'search' ? 'bg-global-8 text-global-1' : 'text-global-4 hover:text-global-1'
              }`}
            >
              🔍 Stock Search
            </button>
            <button
              onClick={() => setActiveTab('portfolio')}
              className={`flex-1 py-2 px-3 rounded text-sm transition-colors ${
                activeTab === 'portfolio' ? 'bg-global-8 text-global-1' : 'text-global-4 hover:text-global-1'
              }`}
            >
              📊 Live Portfolio Analysis
            </button>
          </div>

          {activeTab === 'search' && (
            <div>
              {/* Stock Search */}
              <form onSubmit={handleStockSearch} className="flex gap-3 mb-4">
                <input
                  type="text"
                  value={stockSymbol}
                  onChange={(e) => setStockSymbol(e.target.value.toUpperCase())}
                  className="flex-1 bg-global-6 border border-global-4/20 rounded-lg px-4 py-2 text-global-1 placeholder-global-4 focus:outline-none focus:border-global-8"
                  placeholder="Enter stock symbol (e.g., AAPL, GOOGL, TSLA)"
                />
                <button
                  type="submit"
                  disabled={loading}
                  className="px-6 py-2 bg-global-8 text-global-1 rounded-lg hover:bg-opacity-90 transition-colors disabled:opacity-50"
                >
                  {loading ? 'Analyzing...' : 'Analyze'}
                </button>
              </form>

              {/* Popular Stocks */}
              <div>
                <h3 className="text-sm font-poppins font-bold text-global-1 mb-3">Quick Select:</h3>
                <div className="flex flex-wrap gap-2">
                  {popularStocks.map((stock) => (
                    <button
                      key={stock.symbol}
                      onClick={() => selectPopularStock(stock)}
                      className="px-3 py-1 bg-global-6 text-global-1 rounded-lg text-sm hover:bg-global-8 transition-colors"
                    >
                      {stock.symbol}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'portfolio' && (
            <div>
              {/* Portfolio Analysis Header */}
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-poppins font-bold text-global-1">Live Portfolio Stocks</h3>
                <button
                  onClick={loadPortfolioStocks}
                  disabled={portfolioLoading}
                  className="px-3 py-1 bg-global-8 text-global-1 rounded-lg text-xs hover:bg-opacity-90 transition-colors disabled:opacity-50"
                >
                  {portfolioLoading ? '🔄 Loading...' : '🔄 Refresh All'}
                </button>
              </div>

              {/* Portfolio Stocks Grid */}
              {portfolioLoading ? (
                <div className="text-center py-8">
                  <div className="animate-spin w-8 h-8 border-2 border-global-8 border-t-transparent rounded-full mx-auto mb-3"></div>
                  <div className="text-global-4 text-sm">Loading portfolio stocks...</div>
                </div>
              ) : portfolioStocks.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-60 overflow-y-auto">
                  {portfolioStocks.map((stock, index) => (
                    <div key={index} className="bg-global-6 rounded-lg p-3 border-l-4" style={{ borderLeftColor: stock.risk_color }}>
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <div className="text-sm font-bold text-global-1">{stock.formatted_name}</div>
                          <div className="text-xs text-global-4">{stock.symbol}</div>
                        </div>
                        <div className={`px-2 py-1 rounded-full text-xs font-medium`} 
                             style={{ backgroundColor: stock.risk_color + '20', color: stock.risk_color }}>
                          {stock.risks === 'none' ? 'Low Risk' : stock.risk_level}
                        </div>
                      </div>
                      
                      {stock.has_detailed_analysis && (
                        <div className="text-xs text-global-4 mb-2 line-clamp-2">
                          {stock.summary || 'Analysis available'}
                        </div>
                      )}
                      
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            setStockSymbol(stock.symbol);
                            selectPopularStock({ symbol: stock.symbol, name: stock.name });
                            setActiveTab('search');
                          }}
                          className="flex-1 py-1 bg-global-10 text-global-1 rounded text-xs hover:bg-global-8 transition-colors"
                        >
                          📊 Analyze
                        </button>
                        <button
                          onClick={() => refreshPortfolioStock(stock.name.toLowerCase())}
                          className="px-2 py-1 bg-global-10 text-global-1 rounded text-xs hover:bg-global-8 transition-colors"
                          title="Refresh analysis"
                        >
                          🔄
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <div className="text-2xl mb-3">📈</div>
                  <div className="text-global-4 text-sm">No portfolio stocks found</div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Analysis Results - Only show when in search mode and have data */}
        {activeTab === 'search' && stockData && (
          <div className="space-y-6">
            {/* Stock Overview */}
            <div className="bg-global-6 rounded-[16px] p-4">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-[20px] font-poppins font-black text-global-1">
                    {stockData.symbol}
                  </h3>
                  <p className="text-sm text-global-4">
                    {selectedStock?.name || 'Stock Analysis'}
                  </p>
                </div>
                <button
                  onClick={() => addToWatchlist(stockData.symbol)}
                  className="px-3 py-1 bg-global-8 text-global-1 rounded-lg text-xs hover:bg-opacity-90 transition-colors"
                >
                  + Watchlist
                </button>
              </div>

              {/* Price Info */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-4">
                <div>
                  <div className="text-xs text-global-4">Price</div>
                  <div className="text-[18px] font-poppins font-light text-global-1">
                    ${stockData.price.toFixed(2)}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-global-4">Change</div>
                  <div className={`text-[18px] font-poppins font-light ${
                    stockData.change >= 0 ? 'text-[#00d87a]' : 'text-[#ff0004]'
                  }`}>
                    {stockData.change >= 0 ? '+' : ''}{stockData.change.toFixed(2)} 
                    ({stockData.changePercent.toFixed(2)}%)
                  </div>
                </div>
                <div>
                  <div className="text-xs text-global-4">Volume</div>
                  <div className="text-[18px] font-poppins font-light text-global-1">
                    {(stockData.volume / 1000000).toFixed(1)}M
                  </div>
                </div>
                <div>
                  <div className="text-xs text-global-4">P/E Ratio</div>
                  <div className="text-[18px] font-poppins font-light text-global-1">
                    {stockData.pe.toFixed(1)}
                  </div>
                </div>
              </div>
            </div>

            {/* Analysis Tabs */}
            <div className="bg-global-6 rounded-[16px] p-4">
              <div className="flex mb-4 bg-global-10 rounded-lg p-1">
                {[
                  { key: 'overview', label: '📊 Overview', icon: '📊' },
                  { key: 'technical', label: '📈 Technical', icon: '📈' },
                  { key: 'fundamental', label: '📋 Fundamental', icon: '📋' },
                  { key: 'sentiment', label: '💭 Sentiment', icon: '💭' }
                ].map((tab) => (
                  <button
                    key={tab.key}
                    onClick={() => setAnalysisMode(tab.key)}
                    className={`flex-1 py-2 px-3 rounded text-xs transition-colors ${
                      analysisMode === tab.key ? 'bg-global-8 text-global-1' : 'text-global-4 hover:text-global-1'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* Analysis Content */}
              {analysis && (
                <div className="space-y-4">
                  {analysisMode === 'overview' && (
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="bg-global-10 rounded-lg p-3">
                          <div className="text-xs text-global-4 mb-1">AI Risk Assessment</div>
                          <div className={`text-sm font-bold ${getRiskColor(analysis.risk_assessment.risk_level)}`}>
                            {analysis.risk_assessment.risk_level.toUpperCase()}
                          </div>
                          <div className="text-xs text-global-4">
                            Confidence: {analysis.risk_assessment.confidence}%
                          </div>
                        </div>
                        <div className="bg-global-10 rounded-lg p-3">
                          <div className="text-xs text-global-4 mb-1">Market Cap</div>
                          <div className="text-sm font-bold text-global-1">{stockData.marketCap}</div>
                          <div className="text-xs text-global-4">Beta: {stockData.beta.toFixed(2)}</div>
                        </div>
                      </div>
                      
                      <div className="bg-global-10 rounded-lg p-3">
                        <div className="text-sm font-bold text-global-1 mb-2">🤖 AI Analysis Summary</div>
                        <div className="text-xs text-global-4 leading-relaxed">
                          {analysis.risk_assessment.reasoning}
                        </div>
                      </div>

                      <div className="bg-global-10 rounded-lg p-3">
                        <div className="text-sm font-bold text-global-1 mb-2">💡 AI Recommendations</div>
                        <div className="space-y-1">
                          {analysis.recommendations?.map((rec, index) => (
                            <div key={index} className="text-xs text-global-4 flex items-start gap-2">
                              <span>•</span>
                              <span>{rec}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {analysisMode === 'technical' && analysis.technical && (
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                        <div className="bg-global-10 rounded-lg p-3">
                          <div className="text-xs text-global-4">Trend</div>
                          <div className="text-sm font-bold text-global-1">
                            {getTrendIcon(analysis.technical.trend)} {analysis.technical.trend}
                          </div>
                        </div>
                        <div className="bg-global-10 rounded-lg p-3">
                          <div className="text-xs text-global-4">RSI</div>
                          <div className={`text-sm font-bold ${
                            analysis.technical.rsi > 70 ? 'text-[#ff0004]' :
                            analysis.technical.rsi < 30 ? 'text-[#00d87a]' : 'text-global-1'
                          }`}>
                            {analysis.technical.rsi}
                          </div>
                        </div>
                        <div className="bg-global-10 rounded-lg p-3">
                          <div className="text-xs text-global-4">MACD Signal</div>
                          <div className={`text-sm font-bold ${
                            analysis.technical.macd === 'Buy' ? 'text-[#00d87a]' : 'text-[#ff0004]'
                          }`}>
                            {analysis.technical.macd}
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="bg-global-10 rounded-lg p-3">
                          <div className="text-xs text-global-4 mb-2">Support & Resistance</div>
                          <div className="text-xs space-y-1">
                            <div className="flex justify-between">
                              <span className="text-global-4">Support:</span>
                              <span className="text-[#00d87a]">${analysis.technical.support}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-global-4">Resistance:</span>
                              <span className="text-[#ff0004]">${analysis.technical.resistance}</span>
                            </div>
                          </div>
                        </div>
                        <div className="bg-global-10 rounded-lg p-3">
                          <div className="text-xs text-global-4 mb-1">Volume Analysis</div>
                          <div className="text-sm font-bold text-global-1">
                            {analysis.technical.volume_analysis}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {analysisMode === 'fundamental' && analysis.fundamental && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-3">
                        <div className="bg-global-10 rounded-lg p-3">
                          <div className="text-xs text-global-4">Valuation</div>
                          <div className={`text-sm font-bold ${
                            analysis.fundamental.valuation === 'Undervalued' ? 'text-[#00d87a]' :
                            analysis.fundamental.valuation === 'Overvalued' ? 'text-[#ff0004]' : 'text-global-1'
                          }`}>
                            {analysis.fundamental.valuation}
                          </div>
                        </div>
                        <div className="bg-global-10 rounded-lg p-3">
                          <div className="text-xs text-global-4">Growth Potential</div>
                          <div className="text-sm font-bold text-global-1">
                            {analysis.fundamental.growth_potential}
                          </div>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="bg-global-10 rounded-lg p-3">
                          <div className="text-xs text-global-4">ROE</div>
                          <div className="text-sm font-bold text-global-1">
                            {analysis.fundamental.roe}
                          </div>
                        </div>
                        <div className="bg-global-10 rounded-lg p-3">
                          <div className="text-xs text-global-4">Profit Margin</div>
                          <div className="text-sm font-bold text-global-1">
                            {analysis.fundamental.profit_margin}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {analysisMode === 'sentiment' && analysis.sentiment && (
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="bg-global-10 rounded-lg p-3">
                          <div className="text-xs text-global-4 mb-1">Analyst Rating</div>
                          <div className={`text-sm font-bold ${
                            analysis.sentiment.analyst_rating.includes('Buy') ? 'text-[#00d87a]' :
                            analysis.sentiment.analyst_rating === 'Hold' ? 'text-[#ffe100]' : 'text-[#ff0004]'
                          }`}>
                            {analysis.sentiment.analyst_rating}
                          </div>
                          <div className="text-xs text-global-4">
                            Target: ${analysis.sentiment.price_target}
                          </div>
                        </div>
                        <div className="bg-global-10 rounded-lg p-3">
                          <div className="text-xs text-global-4 mb-1">News Sentiment</div>
                          <div className={`text-sm font-bold ${
                            analysis.sentiment.news_sentiment === 'Positive' ? 'text-[#00d87a]' :
                            analysis.sentiment.news_sentiment === 'Neutral' ? 'text-[#ffe100]' : 'text-[#ff0004]'
                          }`}>
                            {analysis.sentiment.news_sentiment}
                          </div>
                          <div className="text-xs text-global-4">
                            Social: {analysis.sentiment.social_sentiment} positive
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3">
              <button
                onClick={() => addToWatchlist(stockData.symbol)}
                className="flex-1 py-2 bg-global-8 text-global-1 rounded-lg text-sm hover:bg-opacity-90 transition-colors"
              >
                📋 Add to Watchlist
              </button>
              <button
                onClick={() => analyzeStock(stockData.symbol)}
                className="flex-1 py-2 bg-global-6 text-global-1 rounded-lg text-sm hover:bg-global-8 transition-colors"
              >
                🔄 Refresh Analysis
              </button>
              <button
                onClick={() => setActiveTab('portfolio')}
                className="flex-1 py-2 bg-[#00abc9] text-global-1 rounded-lg text-sm hover:bg-opacity-90 transition-colors"
              >
                📊 View Portfolio
              </button>
            </div>
          </div>
        )}

        {/* Empty State for Search Tab */}
        {activeTab === 'search' && !stockData && !loading && (
          <div className="text-center py-12">
            <div className="text-4xl mb-4">📈</div>
            <div className="text-global-1 font-medium mb-2">AI Stock Analysis</div>
            <div className="text-global-4 text-sm">
              Enter a stock symbol above to get comprehensive AI-powered analysis
            </div>
          </div>
        )}

        {/* Portfolio Analysis Detail View */}
        {activeTab === 'portfolio' && portfolioStocks.length > 0 && (
          <div className="mt-6">
            <div className="bg-global-6 rounded-[16px] p-4">
              <h3 className="text-[16px] font-poppins font-black text-global-1 mb-4">
                📊 Portfolio Risk Summary
              </h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                <div className="bg-global-10 rounded-lg p-3">
                  <div className="text-xs text-global-4">Total Stocks</div>
                  <div className="text-2xl font-bold text-global-1">{portfolioStocks.length}</div>
                </div>
                <div className="bg-global-10 rounded-lg p-3">
                  <div className="text-xs text-global-4">Low Risk</div>
                  <div className="text-2xl font-bold text-[#00d87a]">
                    {portfolioStocks.filter(s => s.risks === 'none' || s.risk_level === 'LOW').length}
                  </div>
                </div>
                <div className="bg-global-10 rounded-lg p-3">
                  <div className="text-xs text-global-4">Detailed Analysis</div>
                  <div className="text-2xl font-bold text-global-1">
                    {portfolioStocks.filter(s => s.has_detailed_analysis).length}
                  </div>
                </div>
              </div>
              
              <div className="text-xs text-global-4">
                💡 Click "Analyze" on any stock above for comprehensive AI analysis
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default StockAnalysisTools;