import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const Sidebar = ({ isOpen = true, onToggle }) => {
  const location = useLocation();

  const navigation = [
    { 
      name: 'Expenses Dashboard', 
      href: '/expenses',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
        </svg>
      )
    },
    { 
      name: 'Portfolio Dashboard', 
      href: '/portfolio',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 8v8m-4-5v5m-4-2v2m-2 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
      )
    }
  ];

  return (
    <div className={`${isOpen ? 'w-64' : 'w-16'} bg-secondary-background border-r border-border-primary transition-all duration-300 flex flex-col h-full`}>
      {/* Sidebar Header */}
      <div className="p-4 border-b border-border-primary">
        <div className="flex items-center justify-between">
          {isOpen && (
            <h2 className="text-lg font-semibold font-poppins text-text-primary">
              Navigation
            </h2>
          )}
          <button
            onClick={onToggle}
            className="p-1 rounded-md hover:bg-secondary-light text-text-primary"
            aria-label="Toggle sidebar"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
      </div>
      {/* Navigation Links */}
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {navigation?.map((item) => (
            <li key={item?.name}>
              <Link
                to={item?.href}
                className={`flex items-center px-3 py-2 rounded-md text-sm font-medium font-poppins transition-colors duration-200 ${
                  location?.pathname === item?.href
                    ? 'bg-primary-background text-primary-foreground'
                    : 'text-text-primary hover:bg-secondary-light'
                }`}
                title={!isOpen ? item?.name : ''}
              >
                <span className="flex-shrink-0">
                  {item?.icon}
                </span>
                {isOpen && (
                  <span className="ml-3 truncate">
                    {item?.name}
                  </span>
                )}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
};

export default Sidebar;