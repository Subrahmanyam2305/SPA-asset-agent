// Stock Analysis Service - Dedicated service for AI-powered stock analysis

const API_BASE_URL = 'http://localhost:8000';

class StockAnalysisService {
  async analyzeStock(symbol, analysisType = 'comprehensive') {
    try {
      const response = await fetch(`${API_BASE_URL}/analyze/stock`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          symbol: symbol.toUpperCase(),
          analysis_type: analysisType
        })
      });

      if (!response.ok) {
        throw new Error(`Stock analysis failed: ${response.statusText}`);
      }

      const data = await response.json();
      return this.enrichAnalysisData(data);
    } catch (error) {
      console.error('Stock analysis error:', error);
      // Return fallback mock data
      return this.generateMockAnalysis(symbol);
    }
  }

  async getStockQuote(symbol) {
    try {
      const response = await fetch(`${API_BASE_URL}/stocks/quote/${symbol}`);
      
      if (!response.ok) {
        throw new Error(`Quote fetch failed: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Stock quote error:', error);
      return null;
    }
  }

  async getTrendingStocks() {
    try {
      const response = await fetch(`${API_BASE_URL}/stocks/trending`);
      
      if (!response.ok) {
        throw new Error(`Trending stocks fetch failed: ${response.statusText}`);
      }

      const data = await response.json();
      return data.trending_stocks;
    } catch (error) {
      console.error('Trending stocks error:', error);
      return [];
    }
  }

  async getUserWatchlist(userId = 'default') {
    try {
      const response = await fetch(`${API_BASE_URL}/stocks/watchlist/${userId}`);
      
      if (!response.ok) {
        throw new Error(`Watchlist fetch failed: ${response.statusText}`);
      }

      const data = await response.json();
      return data.watchlist;
    } catch (error) {
      console.error('Watchlist error:', error);
      return ['AAPL', 'GOOGL', 'MSFT', 'TSLA', 'NVDA'];
    }
  }

  async addToWatchlist(symbol, userId = 'default') {
    try {
      const response = await fetch(`${API_BASE_URL}/stocks/watchlist/${userId}?symbol=${symbol}`, {
        method: 'POST'
      });
      
      if (!response.ok) {
        throw new Error(`Add to watchlist failed: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Add to watchlist error:', error);
      return { success: false, message: 'Failed to add to watchlist' };
    }
  }

  enrichAnalysisData(data) {
    // Add additional computed fields and formatting
    return {
      ...data,
      formatted_price: `$${data.current_price.toFixed(2)}`,
      formatted_change: `${data.price_change >= 0 ? '+' : ''}${data.price_change.toFixed(2)} (${data.price_change_percent.toFixed(2)}%)`,
      formatted_volume: this.formatVolume(data.volume),
      risk_color: this.getRiskColor(data.risk_level),
      trend_icon: this.getTrendIcon(data.technical_analysis.trend),
      overall_score: this.calculateOverallScore(data),
      key_metrics: this.extractKeyMetrics(data)
    };
  }

  calculateOverallScore(data) {
    let score = 50; // Base score
    
    // Technical factors
    if (data.technical_analysis.trend === 'BULLISH') score += 15;
    else if (data.technical_analysis.trend === 'BEARISH') score -= 15;
    
    if (data.technical_analysis.rsi < 30) score += 10; // Oversold - good buy
    else if (data.technical_analysis.rsi > 70) score -= 10; // Overbought
    
    if (data.technical_analysis.macd_signal === 'BUY') score += 10;
    else if (data.technical_analysis.macd_signal === 'SELL') score -= 10;
    
    // Fundamental factors
    if (data.fundamental_analysis.valuation === 'UNDERVALUED') score += 15;
    else if (data.fundamental_analysis.valuation === 'OVERVALUED') score -= 15;
    
    if (data.fundamental_analysis.pe_ratio < 15) score += 10;
    else if (data.fundamental_analysis.pe_ratio > 30) score -= 10;
    
    // Sentiment factors
    if (data.sentiment_analysis.analyst_rating.includes('BUY')) score += 10;
    else if (data.sentiment_analysis.analyst_rating === 'SELL') score -= 10;
    
    if (data.sentiment_analysis.news_sentiment === 'POSITIVE') score += 5;
    else if (data.sentiment_analysis.news_sentiment === 'NEGATIVE') score -= 5;
    
    return Math.max(0, Math.min(100, Math.round(score)));
  }

  extractKeyMetrics(data) {
    return [
      {
        label: 'P/E Ratio',
        value: data.fundamental_analysis.pe_ratio,
        status: data.fundamental_analysis.pe_ratio < 20 ? 'good' : data.fundamental_analysis.pe_ratio > 30 ? 'warning' : 'neutral'
      },
      {
        label: 'RSI',
        value: data.technical_analysis.rsi,
        status: data.technical_analysis.rsi < 30 ? 'oversold' : data.technical_analysis.rsi > 70 ? 'overbought' : 'neutral'
      },
      {
        label: 'Beta',
        value: data.fundamental_analysis.beta,
        status: data.fundamental_analysis.beta > 1.5 ? 'high_risk' : data.fundamental_analysis.beta < 0.8 ? 'low_risk' : 'neutral'
      },
      {
        label: 'Dividend Yield',
        value: `${data.fundamental_analysis.dividend_yield}%`,
        status: data.fundamental_analysis.dividend_yield > 3 ? 'good' : 'neutral'
      }
    ];
  }

  getRiskColor(riskLevel) {
    const colors = {
      'HIGH': '#ff0004',
      'MEDIUM': '#ffe100',
      'LOW': '#00d87a'
    };
    return colors[riskLevel] || '#ffe100';
  }

  getTrendIcon(trend) {
    const icons = {
      'BULLISH': '📈',
      'BEARISH': '📉',
      'SIDEWAYS': '📊'
    };
    return icons[trend] || '📊';
  }

  formatVolume(volume) {
    if (volume >= 1000000000) {
      return `${(volume / 1000000000).toFixed(1)}B`;
    } else if (volume >= 1000000) {
      return `${(volume / 1000000).toFixed(1)}M`;
    } else if (volume >= 1000) {
      return `${(volume / 1000).toFixed(1)}K`;
    }
    return volume.toString();
  }

  generateMockAnalysis(symbol) {
    // Fallback mock data for when API is unavailable
    const basePrice = Math.random() * 200 + 50;
    const change = (Math.random() - 0.5) * 10;
    
    return {
      symbol: symbol.toUpperCase(),
      company_name: `${symbol.toUpperCase()} Corporation`,
      current_price: basePrice,
      price_change: change,
      price_change_percent: (change / basePrice) * 100,
      volume: Math.floor(Math.random() * 10000000) + 1000000,
      technical_analysis: {
        rsi: Math.random() * 100,
        macd_signal: change > 0 ? 'BUY' : 'SELL',
        trend: change > 2 ? 'BULLISH' : change < -2 ? 'BEARISH' : 'SIDEWAYS',
        support_level: basePrice * 0.95,
        resistance_level: basePrice * 1.05,
        volume_analysis: 'NORMAL'
      },
      fundamental_analysis: {
        pe_ratio: Math.random() * 30 + 10,
        market_cap: `${Math.floor(Math.random() * 500 + 50)}B`,
        dividend_yield: Math.random() * 4,
        beta: Math.random() * 2 + 0.5,
        roe: `${(Math.random() * 20 + 10).toFixed(1)}%`,
        profit_margin: `${(Math.random() * 25 + 5).toFixed(1)}%`,
        debt_to_equity: Math.random() * 2,
        valuation: 'FAIR'
      },
      sentiment_analysis: {
        analyst_rating: 'HOLD',
        price_target: basePrice * 1.1,
        news_sentiment: 'NEUTRAL',
        social_sentiment_score: Math.floor(Math.random() * 40) + 60
      },
      ai_recommendation: 'HOLD - Limited data available for comprehensive analysis',
      risk_level: 'MEDIUM',
      confidence_score: 70,
      formatted_price: `$${basePrice.toFixed(2)}`,
      formatted_change: `${change >= 0 ? '+' : ''}${change.toFixed(2)}`,
      risk_color: '#ffe100',
      trend_icon: '📊',
      overall_score: 65
    };
  }

  // Utility methods for stock screening
  getPopularStocks() {
    return [
      { symbol: 'AAPL', name: 'Apple Inc.', sector: 'Technology' },
      { symbol: 'GOOGL', name: 'Alphabet Inc.', sector: 'Technology' },
      { symbol: 'MSFT', name: 'Microsoft Corp.', sector: 'Technology' },
      { symbol: 'TSLA', name: 'Tesla Inc.', sector: 'Automotive' },
      { symbol: 'NVDA', name: 'NVIDIA Corp.', sector: 'Semiconductors' },
      { symbol: 'AMZN', name: 'Amazon.com Inc.', sector: 'E-commerce' },
      { symbol: 'META', name: 'Meta Platforms Inc.', sector: 'Social Media' },
      { symbol: 'JPM', name: 'JPMorgan Chase & Co.', sector: 'Banking' },
      { symbol: 'JNJ', name: 'Johnson & Johnson', sector: 'Healthcare' },
      { symbol: 'V', name: 'Visa Inc.', sector: 'Financial Services' }
    ];
  }

  getSectorStocks(sector) {
    const stocksBySector = {
      'Technology': ['AAPL', 'GOOGL', 'MSFT', 'NVDA', 'META'],
      'Healthcare': ['JNJ', 'PFE', 'UNH', 'ABBV', 'MRK'],
      'Financial': ['JPM', 'BAC', 'WFC', 'GS', 'V'],
      'Consumer': ['AMZN', 'TSLA', 'HD', 'MCD', 'NKE'],
      'Energy': ['XOM', 'CVX', 'COP', 'EOG', 'SLB']
    };
    return stocksBySector[sector] || [];
  }

  getRiskColorForLevel(riskLevel) {
    const colors = {
      'LOW': '#00d87a',
      'MEDIUM': '#ffe100',
      'HIGH': '#ff0004',
      'none': '#00d87a'
    };
    return colors[riskLevel] || '#ffe100';
  }

  formatPortfolioStock(stock) {
    return {
      ...stock,
      formatted_name: stock.name,
      risk_color: this.getRiskColorForLevel(stock.risk_level),
      has_detailed_analysis: stock.confidence_score > 70,
      summary: stock.key_insights.join(' • ')
    };
  }
}

export default new StockAnalysisService();