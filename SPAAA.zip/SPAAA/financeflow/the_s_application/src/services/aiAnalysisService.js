// AI Analysis Service - Connects React frontend to Python AI backend

const API_BASE_URL = 'http://localhost:8000';

class AIAnalysisService {
  async analyzeAsset(assetName, assetType, currentValue) {
    try {
      const response = await fetch(`${API_BASE_URL}/analyze/asset`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          asset_name: assetName,
          asset_type: assetType,
          current_value: currentValue
        })
      });

      if (!response.ok) {
        throw new Error(`Analysis failed: ${response.statusText}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Asset analysis error:', error);
      // Return fallback data for demo purposes
      return {
        asset_name: assetName,
        risk_assessment: {
          risk_level: 'medium',
          confidence: 50,
          reasoning: 'Connection to AI service unavailable. Using default risk assessment.',
          timestamp: new Date().toISOString()
        },
        recommendations: ['AI analysis temporarily unavailable']
      };
    }
  }

  async analyzePortfolio(assets) {
    try {
      const response = await fetch(`${API_BASE_URL}/analyze/portfolio`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(assets)
      });

      if (!response.ok) {
        throw new Error(`Portfolio analysis failed: ${response.statusText}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Portfolio analysis error:', error);
      // Return fallback data
      return {
        total_value: assets.reduce((sum, asset) => sum + asset.current_value, 0),
        overall_risk: 'medium',
        asset_insights: [],
        alerts: ['AI portfolio analysis temporarily unavailable']
      };
    }
  }

  async getPortfolioAlerts() {
    try {
      const response = await fetch(`${API_BASE_URL}/portfolio/alerts`);
      
      if (!response.ok) {
        throw new Error(`Failed to get alerts: ${response.statusText}`);
      }

      const data = await response.json();
      return data.alerts || [];
    } catch (error) {
      console.error('Portfolio alerts error:', error);
      return [];
    }
  }

  async checkHealth() {
    try {
      const response = await fetch(`${API_BASE_URL}/health`);
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Health check error:', error);
      return { status: 'unavailable', ai_modules_loaded: false };
    }
  }

  // Utility function to get risk color based on level
  getRiskColor(riskLevel) {
    const riskColors = {
      'high': '#ff0004',
      'medium': '#ffe100', 
      'low': '#00d87a',
      'very_low': '#00abc9',
      'absent': '#00d87a'
    };
    return riskColors[riskLevel] || '#ffe100';
  }

  // Utility function to get risk indicator
  getRiskIndicator(riskLevel) {
    if (riskLevel === 'high') return 'down';
    if (riskLevel === 'medium') return 'neutral';
    return 'up';
  }

  // Convert portfolio data to format expected by the dashboard
  transformPortfolioData(portfolioData, aiInsights = []) {
    return portfolioData.map((item, index) => {
      const insight = aiInsights.find(ai => 
        ai.asset_name.toLowerCase().includes(item.name.toLowerCase())
      );
      
      const riskLevel = insight?.risk_assessment?.risk_level || 'medium';
      
      return {
        ...item,
        id: item.id || index + 1,
        risk_level: riskLevel,
        risk_confidence: insight?.risk_assessment?.confidence || 50,
        risk_reasoning: insight?.risk_assessment?.reasoning || 'No analysis available',
        recommendations: insight?.recommendations || [],
        color: item.color || this.getRiskColor(riskLevel),
        indicator: this.getRiskIndicator(riskLevel),
        indicatorColor: this.getRiskColor(riskLevel)
      };
    });
  }
}

export default new AIAnalysisService();