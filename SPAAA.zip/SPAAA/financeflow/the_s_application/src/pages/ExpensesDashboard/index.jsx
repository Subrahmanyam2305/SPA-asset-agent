import React, { useState } from 'react';
import EditText from '../../components/ui/EditText';

const ExpensesDashboard = () => {
  const [selectedMonth, setSelectedMonth] = useState('January');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [note, setNote] = useState('');

  const expenseCategories = [
    { name: 'Rent', amount: '$1,550' },
    { name: 'Food & Drinks', amount: '$485' },
    { name: 'Shopping', amount: '$950' },
    { name: 'Transportation', amount: '$250' },
    { name: 'Investments', amount: '$8,500' },
    { name: 'Vehicle', amount: '$720' },
    { name: 'Utilities', amount: '$200' },
    { name: 'Charity', amount: '$50' }
  ];

  const navigationItems = [
    { name: 'DASHBOARD', active: false },
    { name: 'EXPENSES', active: true },
    { name: 'PORTFOLIO', active: false },
    { name: 'SETTINGS', active: false }
  ];

  return (
    <div className="w-full min-h-screen bg-[#233ea7] flex flex-row">
      {/* Sidebar */}
      <div className="hidden lg:flex flex-col w-[276px] p-6">
        {/* Logo */}
        <div className="mb-[192px]">
          <img 
            src="/images/img_untitled_2_1.png" 
            alt="Logo" 
            className="w-[208px] h-[208px]"
          />
        </div>

        {/* Navigation */}
        <div className="flex flex-col gap-[34px]">
          {navigationItems?.map((item, index) => (
            <button
              key={index}
              className={`text-[30px] font-poppins font-black leading-[45px] text-left ${
                item?.active ? 'text-[#ffd269]' : 'text-white'
              } hover:text-[#ffd269] transition-colors duration-200`}
            >
              {item?.name}
            </button>
          ))}
        </div>
      </div>
      {/* Main Content */}
      <div className="flex-1 p-4 lg:p-6">
        <div className="w-full max-w-[1354px] mx-auto">
          <div className="bg-white rounded-[24px] p-6 lg:p-8 flex flex-col lg:flex-row gap-6 lg:gap-8">
            
            {/* Expenses Section */}
            <div className="flex-1">
              {/* Header */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
                <h1 className="text-[20px] sm:text-[30px] font-poppins font-black leading-[30px] sm:leading-[45px] text-black">
                  EXPENSES
                </h1>
                
                <EditText
                  placeholder="January"
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(e?.target?.value)}
                  rightImage={{
                    src: "/images/img_keyboardarrowup.svg",
                    width: 30,
                    height: 30
                  }}
                  className="w-full sm:w-[270px] bg-[#e5e5e5] rounded-[24px] px-6 py-[10px] text-[16px] sm:text-[20px] font-poppins font-black leading-[24px] sm:leading-[30px] text-black"
                />
              </div>

              {/* Total Amount */}
              <div className="mb-[52px]">
                <h2 className="text-[36px] sm:text-[48px] lg:text-[72px] font-poppins font-light leading-[54px] sm:leading-[72px] lg:leading-[108px] text-black">
                  $54,958.42
                </h2>
              </div>

              {/* Expense Categories */}
              <div className="space-y-[46px]">
                {expenseCategories?.map((category, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <span className="text-[16px] sm:text-[20px] font-poppins font-black leading-[24px] sm:leading-[30px] text-black">
                      {category?.name}
                    </span>
                    <div className="flex items-center gap-4">
                      <span className="text-[20px] sm:text-[32px] font-poppins font-light leading-[30px] sm:leading-[48px] text-black">
                        {category?.amount}
                      </span>
                      <img 
                        src="/images/img_keyboardarrowup.svg" 
                        alt="Arrow" 
                        className="w-[44px] h-[44px] cursor-pointer hover:opacity-70 transition-opacity duration-200"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* New Expense Form */}
            <div className="w-full lg:w-[322px] bg-[#e5e5e5] rounded-[24px] p-6 lg:p-[26px]">
              <h2 className="text-[20px] sm:text-[30px] font-poppins font-black leading-[30px] sm:leading-[45px] text-center text-black mb-8">
                NEW EXPENSE
              </h2>

              <div className="space-y-6">
                {/* Category */}
                <div>
                  <label className="block text-[16px] sm:text-[20px] font-poppins font-black leading-[24px] sm:leading-[30px] text-black mb-4">
                    Category
                  </label>
                  <div className="bg-white rounded-[24px] p-2 flex justify-end items-center">
                    <img 
                      src="/images/img_keyboardarrowup.svg" 
                      alt="Dropdown" 
                      className="w-[30px] h-[30px] cursor-pointer"
                    />
                  </div>
                </div>

                {/* Date */}
                <div>
                  <label className="block text-[16px] sm:text-[20px] font-poppins font-black leading-[24px] sm:leading-[30px] text-black mb-4">
                    Date
                  </label>
                  <div className="bg-white rounded-[24px] p-2 flex justify-end items-center">
                    <img 
                      src="/images/img_keyboardarrowup.svg" 
                      alt="Date picker" 
                      className="w-[30px] h-[30px] cursor-pointer"
                    />
                  </div>
                </div>

                {/* Note */}
                <div>
                  <label className="block text-[16px] sm:text-[20px] font-poppins font-black leading-[24px] sm:leading-[30px] text-black mb-4">
                    Note
                  </label>
                  <div className="bg-white rounded-[24px] w-full h-[200px] sm:h-[300px] lg:h-[380px]">
                    {/* Note input area */}
                  </div>
                </div>

                {/* Add Button */}
                <div className="flex justify-end mt-[38px]">
                  <button className="bg-[#ffd269] rounded-[50px] p-[10px] hover:bg-[#e6bd5e] transition-colors duration-200">
                    <img 
                      src="/images/img_plus.svg" 
                      alt="Add" 
                      className="w-[80px] h-[80px]"
                    />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Mobile Menu Button */}
      <button className="lg:hidden fixed top-4 left-4 z-50 bg-white rounded-lg p-2 shadow-lg">
        <div className="w-6 h-6 flex flex-col justify-center items-center">
          <span className="block w-4 h-0.5 bg-black mb-1"></span>
          <span className="block w-4 h-0.5 bg-black mb-1"></span>
          <span className="block w-4 h-0.5 bg-black"></span>
        </div>
      </button>
    </div>
  );
};

export default ExpensesDashboard;