import React, { useState } from 'react';

const SettingsPage = ({ profileName, onUpdateProfile }) => {
  const [tempProfileName, setTempProfileName] = useState(profileName);
  const [currency, setCurrency] = useState('USD');
  const [theme, setTheme] = useState('dark');
  const [notifications, setNotifications] = useState({
    riskAlerts: true,
    portfolioUpdates: true,
    marketNews: false,
    emailReports: true
  });
  const [riskTolerance, setRiskTolerance] = useState('moderate');
  const [autoRebalance, setAutoRebalance] = useState(false);

  const handleSaveProfile = () => {
    onUpdateProfile(tempProfileName);
  };

  const handleNotificationChange = (key) => {
    setNotifications(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  return (
    <div className="flex flex-col gap-6 sm:gap-8">
      {/* Settings Header */}
      <div className="flex flex-col gap-2">
        <h1 className="text-[20px] sm:text-[24px] lg:text-[30px] font-poppins font-black text-global-1">
          SETTINGS
        </h1>
        <div className="text-xs text-global-4">
          Manage your profile and portfolio preferences
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Profile Settings */}
        <div className="bg-global-6 rounded-[24px] p-6">
          <h2 className="text-[18px] font-poppins font-black text-global-1 mb-4">
            👤 Profile Information
          </h2>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
                Display Name
              </label>
              <input
                type="text"
                value={tempProfileName}
                onChange={(e) => setTempProfileName(e.target.value)}
                className="w-full bg-global-10 border border-global-4/20 rounded-lg px-3 py-2 text-global-1 text-sm focus:outline-none focus:border-global-8"
                placeholder="Enter your name"
              />
            </div>

            <div>
              <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
                Preferred Currency
              </label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full bg-global-10 border border-global-4/20 rounded-lg px-3 py-2 text-global-1 text-sm focus:outline-none focus:border-global-8"
              >
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
                <option value="GBP">GBP (£)</option>
                <option value="JPY">JPY (¥)</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
                Theme
              </label>
              <div className="flex gap-2">
                <button
                  onClick={() => setTheme('dark')}
                  className={`flex-1 py-2 px-3 rounded-lg text-xs transition-colors ${
                    theme === 'dark' ? 'bg-global-8 text-global-1' : 'bg-global-10 text-global-4'
                  }`}
                >
                  🌙 Dark
                </button>
                <button
                  onClick={() => setTheme('light')}
                  className={`flex-1 py-2 px-3 rounded-lg text-xs transition-colors ${
                    theme === 'light' ? 'bg-global-8 text-global-1' : 'bg-global-10 text-global-4'
                  }`}
                >
                  ☀️ Light
                </button>
              </div>
            </div>

            <button
              onClick={handleSaveProfile}
              className="w-full bg-global-8 text-global-1 py-2 px-4 rounded-lg text-sm font-medium hover:bg-opacity-90 transition-colors"
            >
              Save Profile Changes
            </button>
          </div>
        </div>

        {/* Portfolio Settings */}
        <div className="bg-global-6 rounded-[24px] p-6">
          <h2 className="text-[18px] font-poppins font-black text-global-1 mb-4">
            📊 Portfolio Settings
          </h2>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
                Risk Tolerance
              </label>
              <select
                value={riskTolerance}
                onChange={(e) => setRiskTolerance(e.target.value)}
                className="w-full bg-global-10 border border-global-4/20 rounded-lg px-3 py-2 text-global-1 text-sm focus:outline-none focus:border-global-8"
              >
                <option value="conservative">Conservative</option>
                <option value="moderate">Moderate</option>
                <option value="aggressive">Aggressive</option>
              </select>
            </div>

            <div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoRebalance}
                  onChange={(e) => setAutoRebalance(e.target.checked)}
                  className="w-4 h-4 text-global-8 bg-global-10 border-global-4 rounded focus:ring-global-8 focus:ring-2"
                />
                <span className="text-sm font-poppins font-medium text-global-1">
                  Auto-rebalance portfolio
                </span>
              </label>
              <p className="text-xs text-global-4 mt-1 ml-6">
                Automatically rebalance when allocations drift beyond 5%
              </p>
            </div>
          </div>
        </div>

        {/* Notification Settings */}
        <div className="bg-global-6 rounded-[24px] p-6">
          <h2 className="text-[18px] font-poppins font-black text-global-1 mb-4">
            🔔 Notifications
          </h2>
          
          <div className="space-y-3">
            {[
              { key: 'riskAlerts', label: 'Risk Alerts', desc: 'Get notified of high-risk changes' },
              { key: 'portfolioUpdates', label: 'Portfolio Updates', desc: 'Daily portfolio performance summary' },
              { key: 'marketNews', label: 'Market News', desc: 'Relevant market news and analysis' },
              { key: 'emailReports', label: 'Email Reports', desc: 'Weekly portfolio reports via email' }
            ].map((item) => (
              <div key={item.key}>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={notifications[item.key]}
                    onChange={() => handleNotificationChange(item.key)}
                    className="w-4 h-4 text-global-8 bg-global-10 border-global-4 rounded focus:ring-global-8 focus:ring-2"
                  />
                  <div>
                    <span className="text-sm font-poppins font-medium text-global-1">
                      {item.label}
                    </span>
                    <p className="text-xs text-global-4">
                      {item.desc}
                    </p>
                  </div>
                </label>
              </div>
            ))}
          </div>
        </div>

        {/* AI Settings */}
        <div className="bg-global-6 rounded-[24px] p-6">
          <h2 className="text-[18px] font-poppins font-black text-global-1 mb-4">
            🤖 AI Analysis Settings
          </h2>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
                Analysis Frequency
              </label>
              <select
                className="w-full bg-global-10 border border-global-4/20 rounded-lg px-3 py-2 text-global-1 text-sm focus:outline-none focus:border-global-8"
              >
                <option value="realtime">Real-time</option>
                <option value="hourly">Every Hour</option>
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-poppins font-medium text-global-1 mb-2">
                Risk Sensitivity
              </label>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((level) => (
                  <button
                    key={level}
                    className={`flex-1 py-2 text-xs rounded transition-colors ${
                      level <= 3 ? 'bg-global-8 text-global-1' : 'bg-global-10 text-global-4'
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
              <p className="text-xs text-global-4 mt-1">
                Higher sensitivity = more frequent risk alerts
              </p>
            </div>

            <div className="pt-3 border-t border-global-4/20">
              <div className="flex items-center justify-between">
                <span className="text-xs text-global-4">AI Service Status</span>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#00d87a] rounded-full"></div>
                  <span className="text-xs text-global-1">Connected</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="bg-[#ff0004]/10 border border-[#ff0004]/20 rounded-[24px] p-6">
        <h2 className="text-[18px] font-poppins font-black text-[#ff0004] mb-4">
          ⚠️ Danger Zone
        </h2>
        
        <div className="space-y-3">
          <button className="w-full bg-transparent border border-[#ff0004]/50 text-[#ff0004] py-2 px-4 rounded-lg text-sm font-medium hover:bg-[#ff0004]/10 transition-colors">
            Reset All Settings
          </button>
          <button className="w-full bg-[#ff0004] text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-[#ff0004]/90 transition-colors">
            Delete Portfolio Data
          </button>
          <p className="text-xs text-global-4 text-center">
            These actions cannot be undone. Use with caution.
          </p>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;