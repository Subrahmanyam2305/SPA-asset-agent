import React, { useState, useEffect } from 'react';
import RiskAlerts from '../../components/ui/RiskAlerts';
import AssetAnalysis from '../../components/ui/AssetAnalysis';
import StockAnalysisTools from '../../components/ui/StockAnalysisTools';
import aiAnalysisService from '../../services/aiAnalysisService';
import stockAnalysisService from '../../services/stockAnalysisService';

const DashboardPage = ({ portfolioItems, profileName, onUpdatePortfolio }) => {
  const [portfolioAnalysis, setPortfolioAnalysis] = useState(null);
  const [analysisLoading, setAnalysisLoading] = useState(false);
  const [showAIInsights, setShowAIInsights] = useState(false);
  const [selectedView, setSelectedView] = useState('grid');
  const [showStockAnalysis, setShowStockAnalysis] = useState(false);

  // Calculate total portfolio value
  const totalPortfolioValue = portfolioItems.reduce((sum, item) => {
    return sum + parseFloat(item.value.replace(/[$,]/g, ''));
  }, 0);

  // Run AI analysis on portfolio when component mounts
  useEffect(() => {
    const runPortfolioAnalysis = async () => {
      setAnalysisLoading(true);
      try {
        const assets = portfolioItems.map(item => ({
          asset_name: item.name,
          asset_type: item.name.toLowerCase(),
          current_value: parseFloat(item.value.replace(/[$,]/g, ''))
        }));

        const analysis = await aiAnalysisService.analyzePortfolio(assets);
        setPortfolioAnalysis(analysis);
      } catch (error) {
        console.error('Portfolio analysis failed:', error);
      } finally {
        setAnalysisLoading(false);
      }
    };

    runPortfolioAnalysis();
  }, [portfolioItems]);

  const handleAssetAnalysisComplete = (assetId, analysis) => {
    console.log(`Analysis complete for asset ${assetId}:`, analysis);
  };

  const renderGridView = () => (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {portfolioItems.map((item) => (
        <div key={item.id} className="bg-global-6 rounded-[16px] p-4">
          <div className="flex flex-col gap-3">
            {/* Asset Header */}
            <div className="flex items-center gap-3">
              <div className={`w-[50px] h-[50px] ${item.color} rounded-full flex-shrink-0`}></div>
              <div className="flex-1">
                <div className="text-[14px] font-poppins font-bold text-global-1">
                  {item.name}
                </div>
                <div className="text-xs text-global-4">
                  {item.category}
                </div>
              </div>
              {item.indicator === 'up' && (
                <img 
                  src="/images/img_polygon_1.svg" 
                  alt="Up indicator" 
                  className="w-[20px] h-[20px]"
                />
              )}
              {item.indicator === 'down' && (
                <img 
                  src="/images/img_polygon_2.svg" 
                  alt="Down indicator" 
                  className="w-[20px] h-[20px]"
                />
              )}
            </div>

            {/* Value and Allocation */}
            <div className="space-y-2">
              <div className="text-[18px] font-poppins font-light text-global-1">
                {item.value}
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-global-4">{item.allocation}% of portfolio</span>
                <div className="w-16 bg-global-10 rounded-full h-1">
                  <div 
                    className={`h-full rounded-full ${item.color}`}
                    style={{ width: `${Math.min(item.allocation * 2, 100)}%` }}
                  ></div>
                </div>
              </div>
            </div>

            {/* Details */}
            <div className="text-xs text-global-4 bg-global-10 rounded-lg p-2">
              {item.details}
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  const renderListView = () => (
    <div className="flex flex-col gap-3">
      {showAIInsights ? (
        portfolioItems.map((item) => (
          <AssetAnalysis
            key={item.id}
            asset={item}
            onAnalysisComplete={handleAssetAnalysisComplete}
          />
        ))
      ) : (
        portfolioItems.map((item) => (
          <div key={item.id} className="flex items-center justify-between bg-global-6 rounded-[16px] p-4">
            <div className="flex items-center gap-4">
              <div className={`w-[50px] h-[50px] ${item.color} rounded-full`}></div>
              <div>
                <div className="text-[16px] font-poppins font-black text-global-1">
                  {item.name}
                </div>
                <div className="text-xs text-global-4">
                  {item.category} • {item.details}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <div className="text-[18px] font-poppins font-light text-global-1">
                  {item.value}
                </div>
                <div className="text-xs text-global-4">
                  {item.allocation}%
                </div>
              </div>
              {item.indicator === 'up' && (
                <img 
                  src="/images/img_polygon_1.svg" 
                  alt="Up indicator" 
                  className="w-[25px] h-[25px]"
                />
              )}
              {item.indicator === 'down' && (
                <img 
                  src="/images/img_polygon_2.svg" 
                  alt="Down indicator" 
                  className="w-[25px] h-[25px]"
                />
              )}
            </div>
          </div>
        ))
      )}
    </div>
  );

  return (
    <div className="flex flex-col lg:flex-row gap-4 sm:gap-6">
      {/* Main Portfolio Section */}
      <div className="flex-1">
        <div className="flex flex-col gap-6 sm:gap-8">
          {/* Portfolio Header */}
          <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div className="flex flex-col">
                <h1 className="text-[20px] sm:text-[24px] lg:text-[30px] font-poppins font-black text-global-1">
                  {profileName}'s PORTFOLIO
                </h1>
                <div className="text-xs text-global-4">
                  {portfolioItems.length} Assets • Last updated: {new Date().toLocaleDateString()}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex bg-global-6 rounded-lg p-1">
                  <button
                    onClick={() => setSelectedView('grid')}
                    className={`px-2 py-1 rounded text-xs transition-colors ${
                      selectedView === 'grid' ? 'bg-global-8 text-global-1' : 'text-global-4 hover:text-global-1'
                    }`}
                  >
                    📊 Grid
                  </button>
                  <button
                    onClick={() => setSelectedView('list')}
                    className={`px-2 py-1 rounded text-xs transition-colors ${
                      selectedView === 'list' ? 'bg-global-8 text-global-1' : 'text-global-4 hover:text-global-1'
                    }`}
                  >
                    📋 List
                  </button>
                </div>
                <button
                  onClick={() => setShowAIInsights(!showAIInsights)}
                  className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                    showAIInsights 
                      ? 'bg-global-8 text-global-1' 
                      : 'bg-global-6 text-global-4 hover:text-global-1'
                  }`}
                >
                  🤖 AI Insights
                </button>
                <button
                  onClick={() => setShowStockAnalysis(true)}
                  className="px-3 py-1 bg-[#00abc9] text-global-1 rounded-lg text-xs hover:bg-opacity-90 transition-colors"
                >
                  📈 Stock Analysis
                </button>
                {analysisLoading && (
                  <div className="text-xs text-global-4 flex items-center gap-1">
                    <div className="animate-spin w-3 h-3 border border-global-4 border-t-transparent rounded-full"></div>
                    Analyzing...
                  </div>
                )}
              </div>
            </div>

            {/* Portfolio Value */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div className="flex flex-col">
                <span className="text-[36px] sm:text-[48px] lg:text-[72px] font-poppins font-light text-global-1">
                  ${portfolioAnalysis ? portfolioAnalysis.total_value.toLocaleString() : totalPortfolioValue.toLocaleString()}
                </span>
                <div className="text-sm text-global-4">
                  Total Portfolio Value
                </div>
                {portfolioAnalysis && (
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-xs font-poppins font-medium text-global-4">
                      Overall Risk:
                    </span>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                      portfolioAnalysis.overall_risk === 'high' ? 'bg-[#ff0004] text-white' :
                      portfolioAnalysis.overall_risk === 'medium' ? 'bg-[#ffe100] text-black' :
                      'bg-[#00d87a] text-white'
                    }`}>
                      {portfolioAnalysis.overall_risk.toUpperCase()}
                    </span>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2">
                <img 
                  src="/images/img_polygon_1.svg" 
                  alt="Growth indicator" 
                  className="w-[28px] h-[31px] sm:w-[42px] sm:h-[46px] lg:w-[56px] lg:h-[62px]"
                />
                <span className="text-[16px] sm:text-[20px] lg:text-[24px] font-poppins font-bold text-global-2">
                  3.2%
                </span>
              </div>
            </div>
          </div>

          {/* Portfolio Items */}
          <div>
            {selectedView === 'grid' ? renderGridView() : renderListView()}
          </div>
        </div>
      </div>

      {/* AI Insights / Portfolio Summary Sidebar */}
      <div className="w-full lg:w-[322px]">
        {showAIInsights ? (
          <div className="space-y-4">
            <RiskAlerts portfolioData={portfolioItems} />
            
            {/* Quick Stock Analysis */}
            <div className="bg-global-6 rounded-[24px] p-4">
              <h3 className="text-[16px] font-poppins font-black text-global-1 mb-3">
                📈 Stock Tools
              </h3>
              <div className="space-y-2">
                <button
                  onClick={() => setShowStockAnalysis(true)}
                  className="w-full text-left p-3 bg-global-10 rounded-lg text-sm text-global-1 hover:bg-global-8 hover:text-global-1 transition-colors"
                >
                  🔍 AI Stock Analyzer
                </button>
                <div className="text-xs text-global-4 px-3">
                  Analyze any stock with comprehensive AI insights
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-global-6 rounded-[24px] p-4 sm:p-5">
            <div className="flex flex-col gap-4 sm:gap-6">
              <h3 className="text-[16px] sm:text-[18px] font-poppins font-black text-global-1">
                📈 Portfolio Summary
              </h3>
              
              {/* Asset Allocation Chart */}
              <div className="space-y-3">
                {portfolioItems.map((item) => (
                  <div key={item.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 ${item.color} rounded-full`}></div>
                      <span className="text-xs text-global-1">{item.name}</span>
                    </div>
                    <span className="text-xs text-global-4">{item.allocation}%</span>
                  </div>
                ))}
              </div>

              {/* Quick Stats */}
              <div className="space-y-2 pt-3 border-t border-global-4/20">
                <div className="flex justify-between text-xs">
                  <span className="text-global-4">Best Performer</span>
                  <span className="text-global-2">Real Estate</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-global-4">Most Volatile</span>
                  <span className="text-[#ffe100]">Crypto</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-global-4">Diversification</span>
                  <span className="text-global-2">Well Balanced</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Stock Analysis Modal */}
      {showStockAnalysis && (
        <StockAnalysisTools onClose={() => setShowStockAnalysis(false)} />
      )}
    </div>
  );
};

export default DashboardPage;