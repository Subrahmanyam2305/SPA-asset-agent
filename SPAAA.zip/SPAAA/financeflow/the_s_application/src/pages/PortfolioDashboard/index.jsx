import React, { useState, useEffect } from 'react';
import RiskAlerts from '../../components/ui/RiskAlerts';
import AssetAnalysis from '../../components/ui/AssetAnalysis';
import aiAnalysisService from '../../services/aiAnalysisService';

const PortfolioDashboard = () => {
  const [selectedTab, setSelectedTab] = useState('PORTFOLIO');
  const [portfolioAnalysis, setPortfolioAnalysis] = useState(null);
  const [analysisLoading, setAnalysisLoading] = useState(false);
  const [showAIInsights, setShowAIInsights] = useState(false);
  const [selectedView, setSelectedView] = useState('grid'); // 'grid' or 'list'
  const [profileName, setProfileName] = useState('Portfolio Manager');
  
  // Calculate total portfolio value
  const totalPortfolioValue = portfolioItems.reduce((sum, item) => {
    return sum + parseFloat(item.value.replace(/[$,]/g, ''));
  }, 0);

  const [portfolioItems, setPortfolioItems] = useState([
    {
      id: 1,
      name: 'Real Estate',
      category: 'Property',
      value: '$680,550',
      allocation: 34.3,
      color: 'bg-[#ff0004]',
      indicator: 'up',
      indicatorColor: 'bg-global-8',
      details: 'Primary residence + 2 rental properties'
    },
    {
      id: 2,
      name: 'Stocks',
      category: 'Equities',
      value: '$575,485',
      allocation: 29.0,
      color: 'bg-[#00abc9]',
      indicator: 'up',
      indicatorColor: 'bg-global-2',
      details: 'S&P 500 index funds, tech stocks'
    },
    {
      id: 3,
      name: 'Cryptocurrencies',
      category: 'Digital Assets',
      value: '$420,950',
      allocation: 21.2,
      color: 'bg-[#ffe100]',
      indicator: 'up',
      indicatorColor: 'bg-global-2',
      details: 'Bitcoin, Ethereum, altcoins'
    },
    {
      id: 4,
      name: 'Bonds',
      category: 'Fixed Income',
      value: '$156,200',
      allocation: 7.9,
      color: 'bg-[#00d87a]',
      indicator: 'neutral',
      indicatorColor: 'bg-global-8',
      details: 'Government and corporate bonds'
    },
    {
      id: 5,
      name: 'Artwork',
      category: 'Collectibles',
      value: '$62,850',
      allocation: 3.2,
      color: 'bg-[#c900b2]',
      indicator: 'neutral',
      indicatorColor: 'bg-global-8',
      details: 'Contemporary art pieces'
    },
    {
      id: 6,
      name: 'Wine',
      category: 'Collectibles',
      value: '$48,500',
      allocation: 2.4,
      color: 'bg-[#9c27b0]',
      indicator: 'up',
      indicatorColor: 'bg-global-2',
      details: 'Vintage Bordeaux collection'
    },
    {
      id: 7,
      name: 'Vehicles',
      category: 'Transportation',
      value: '$42,000',
      allocation: 2.1,
      color: 'bg-[#4800ff]',
      indicator: 'down',
      indicatorColor: 'bg-[#ff0004]',
      details: '2 vehicles (depreciating)'
    }
  ]);

  const expenseCategories = [
    { name: 'Rent', percentage: 22 },
    { name: 'Food & Drinks', percentage: 16 },
    { name: 'Shopping', percentage: 6 },
    { name: 'Transportation', percentage: 22 },
    { name: 'Vehicle', percentage: 22 },
    { name: 'Investments', percentage: 42 },
    { name: 'Utilities', percentage: 6 }
  ];

  // Run AI analysis on portfolio when component mounts
  useEffect(() => {
    const runPortfolioAnalysis = async () => {
      setAnalysisLoading(true);
      try {
        const assets = portfolioItems.map(item => ({
          asset_name: item.name,
          asset_type: item.name.toLowerCase(),
          current_value: parseFloat(item.value.replace(/[$,]/g, ''))
        }));

        const analysis = await aiAnalysisService.analyzePortfolio(assets);
        setPortfolioAnalysis(analysis);
      } catch (error) {
        console.error('Portfolio analysis failed:', error);
      } finally {
        setAnalysisLoading(false);
      }
    };

    runPortfolioAnalysis();
  }, []);

  const handleAssetAnalysisComplete = (assetId, analysis) => {
    // Update portfolio item with analysis results
    console.log(`Analysis complete for asset ${assetId}:`, analysis);
  };

  return (
    <div className="w-full bg-[#233ea7] min-h-screen">
      <div className="w-full max-w-[1354px] mx-auto">
        <div className="flex flex-col lg:flex-row p-4 sm:p-6 gap-4 sm:gap-6">
          {/* Sidebar */}
          <div className="w-full lg:w-auto lg:min-w-[276px]">
            <div className="flex flex-col items-start gap-4 sm:gap-6">
              {/* Logo */}
              <div className="w-full flex justify-center lg:justify-start">
                <img 
                  src="/images/img_untitled_2_1.png" 
                  alt="Logo" 
                  className="w-[104px] h-[104px] sm:w-[156px] sm:h-[156px] lg:w-[208px] lg:h-[208px]"
                />
              </div>
              
              {/* Navigation Menu */}
              <div className="flex flex-row lg:flex-col gap-4 sm:gap-6 lg:gap-8 w-full justify-center lg:justify-start">
                <button 
                  className="text-[15px] sm:text-[20px] lg:text-[30px] font-poppins font-black leading-tight text-global-3"
                  onClick={() => setSelectedTab('DASHBOARD')}
                >
                  DASHBOARD
                </button>
                <button 
                  className="text-[15px] sm:text-[20px] lg:text-[30px] font-poppins font-black leading-tight text-global-4"
                  onClick={() => setSelectedTab('EXPENSES')}
                >
                  EXPENSES
                </button>
                <button 
                  className="text-[15px] sm:text-[20px] lg:text-[30px] font-poppins font-black leading-tight text-global-4"
                  onClick={() => setSelectedTab('PORTFOLIO')}
                >
                  PORTFOLIO
                </button>
                <button 
                  className="text-[15px] sm:text-[20px] lg:text-[30px] font-poppins font-black leading-tight text-global-4"
                  onClick={() => setSelectedTab('SETTINGS')}
                >
                  SETTINGS
                </button>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 bg-global-10 rounded-[24px] p-4 sm:p-6 lg:p-7">
            <div className="flex flex-col lg:flex-row gap-4 sm:gap-6">
              {/* Portfolio Section */}
              <div className="flex-1">
                <div className="flex flex-col gap-6 sm:gap-8 lg:gap-11">
                  {/* Portfolio Header */}
                  <div className="flex flex-col gap-2">
                    <h1 className="text-[20px] sm:text-[24px] lg:text-[30px] font-poppins font-black text-global-1">
                      PORTFOLIO
                    </h1>
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                      <span className="text-[36px] sm:text-[48px] lg:text-[72px] font-poppins font-light text-global-1">
                        $1,985,247.95
                      </span>
                      <div className="flex items-center gap-2">
                        <img 
                          src="/images/img_polygon_1.svg" 
                          alt="Growth indicator" 
                          className="w-[28px] h-[31px] sm:w-[42px] sm:h-[46px] lg:w-[56px] lg:h-[62px]"
                        />
                        <span className="text-[16px] sm:text-[20px] lg:text-[24px] font-poppins font-bold text-global-2">
                          3.2%
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Portfolio Items */}
                  <div className="flex flex-col gap-4 sm:gap-6">
                    {portfolioItems?.map((item, index) => (
                      <div key={item?.id} className="flex items-center justify-between">
                        <div className="flex items-center gap-4 sm:gap-6">
                          <div className={`w-[37px] h-[37px] sm:w-[56px] sm:h-[56px] lg:w-[74px] lg:h-[74px] ${item?.color} rounded-full`}></div>
                          <span className="text-[14px] sm:text-[16px] lg:text-[20px] font-poppins font-black text-global-1">
                            {item?.name}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 sm:gap-4">
                          <span className="text-[20px] sm:text-[24px] lg:text-[32px] font-poppins font-light text-global-1">
                            {item?.value}
                          </span>
                          {item?.indicator === 'up' && (
                            <img 
                              src="/images/img_polygon_1.svg" 
                              alt="Up indicator" 
                              className="w-[17px] h-[17px] sm:w-[25px] sm:h-[25px] lg:w-[34px] lg:h-[34px]"
                            />
                          )}
                          {item?.indicator === 'down' && (
                            <img 
                              src="/images/img_polygon_2.svg" 
                              alt="Down indicator" 
                              className="w-[17px] h-[17px] sm:w-[25px] sm:h-[25px] lg:w-[34px] lg:h-[34px]"
                            />
                          )}
                          {item?.indicator === 'neutral' && (
                            <div className={`w-[12px] h-[12px] sm:w-[18px] sm:h-[18px] lg:w-[24px] lg:h-[24px] ${item?.indicatorColor} rounded-full`}></div>
                          )}
                        </div>
                      </div>
                    ))
                    )}
                  </div>

                  {/* Portfolio Button */}
                  <div className="flex justify-center lg:justify-start mt-4 sm:mt-6">
                    <button className="bg-global-8 text-global-1 px-6 sm:px-8 lg:px-12 py-2 sm:py-3 lg:py-4 rounded-[24px] text-[20px] sm:text-[24px] lg:text-[30px] font-poppins font-black">
                      PORTFOLIO
                    </button>
                  </div>
                </div>
              </div>

              {/* AI Insights / Expenses Sidebar */}
              <div className="w-full lg:w-[322px]">
                {showAIInsights ? (
                  <RiskAlerts portfolioData={portfolioItems} />
                ) : (
                  <div className="bg-global-6 rounded-[24px] p-4 sm:p-5">
                    <div className="flex flex-col gap-4 sm:gap-6">
                      {/* Header */}
                      <div className="text-center lg:text-left">
                        <h2 className="text-[16px] sm:text-[20px] lg:text-[24px] font-poppins font-black text-global-1 mb-4 sm:mb-6 lg:mb-8">
                          Where your Money goes?
                        </h2>
                      </div>

                  {/* Expense Categories */}
                  <div className="flex flex-col gap-3 sm:gap-4">
                    {expenseCategories?.map((category, index) => (
                      <div key={index} className="flex flex-col gap-2">
                        <span className="text-[14px] sm:text-[16px] lg:text-[20px] font-poppins font-black text-global-1">
                          {category?.name}
                        </span>
                        <div className="w-full bg-global-10 rounded-[14px] h-[15px] sm:h-[22px] lg:h-[30px]">
                          <div 
                            className="bg-global-8 h-full rounded-[14px]" 
                            style={{ width: `${category?.percentage}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>

                      {/* Expenses Button */}
                      <div className="flex justify-center mt-6 sm:mt-8 lg:mt-12">
                        <button className="bg-global-8 text-global-1 px-6 sm:px-8 lg:px-12 py-2 sm:py-3 lg:py-4 rounded-[24px] text-[20px] sm:text-[24px] lg:text-[30px] font-poppins font-black">
                          EXPENSES
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PortfolioDashboard;