import React, { useState } from 'react';
import DashboardPage from '../DashboardPage';
import ExpensesPage from '../ExpensesPage';
import SettingsPage from '../SettingsPage';

const MainApp = () => {
  const [selectedTab, setSelectedTab] = useState('DASHBOARD');
  const [profileName, setProfileName] = useState('Portfolio Manager');
  
  // Extended portfolio with all asset types
  const [portfolioItems, setPortfolioItems] = useState([
    {
      id: 1,
      name: 'Real Estate',
      category: 'Property',
      value: '$680,550',
      allocation: 34.3,
      color: 'bg-[#ff0004]',
      indicator: 'up',
      indicatorColor: 'bg-global-8',
      details: 'Primary residence + 2 rental properties'
    },
    {
      id: 2,
      name: 'Stocks',
      category: 'Equities',
      value: '$575,485',
      allocation: 29.0,
      color: 'bg-[#00abc9]',
      indicator: 'up',
      indicatorColor: 'bg-global-2',
      details: 'S&P 500 index funds, tech stocks'
    },
    {
      id: 3,
      name: 'Cryptocurrencies',
      category: 'Digital Assets',
      value: '$420,950',
      allocation: 21.2,
      color: 'bg-[#ffe100]',
      indicator: 'up',
      indicatorColor: 'bg-global-2',
      details: 'Bitcoin, Ethereum, altcoins'
    },
    {
      id: 4,
      name: 'Bonds',
      category: 'Fixed Income',
      value: '$156,200',
      allocation: 7.9,
      color: 'bg-[#00d87a]',
      indicator: 'neutral',
      indicatorColor: 'bg-global-8',
      details: 'Government and corporate bonds'
    },
    {
      id: 5,
      name: 'Artwork',
      category: 'Collectibles',
      value: '$62,850',
      allocation: 3.2,
      color: 'bg-[#c900b2]',
      indicator: 'neutral',
      indicatorColor: 'bg-global-8',
      details: 'Contemporary art pieces'
    },
    {
      id: 6,
      name: 'Wine Collection',
      category: 'Collectibles',
      value: '$48,500',
      allocation: 2.4,
      color: 'bg-[#9c27b0]',
      indicator: 'up',
      indicatorColor: 'bg-global-2',
      details: 'Vintage Bordeaux collection'
    },
    {
      id: 7,
      name: 'Vehicles',
      category: 'Transportation',
      value: '$42,000',
      allocation: 2.1,
      color: 'bg-[#4800ff]',
      indicator: 'down',
      indicatorColor: 'bg-[#ff0004]',
      details: '2 vehicles (depreciating)'
    },
    {
      id: 8,
      name: 'Precious Metals',
      category: 'Commodities',
      value: '$28,750',
      allocation: 1.4,
      color: 'bg-[#ff6b00]',
      indicator: 'up',
      indicatorColor: 'bg-global-2',
      details: 'Gold and silver holdings'
    },
    {
      id: 9,
      name: 'Cash & Savings',
      category: 'Cash',
      value: '$15,200',
      allocation: 0.8,
      color: 'bg-[#666666]',
      indicator: 'neutral',
      indicatorColor: 'bg-global-8',
      details: 'Emergency fund and checking'
    }
  ]);

  // Calculate total portfolio value and update allocations
  const updatePortfolioAllocations = (items) => {
    const total = items.reduce((sum, item) => {
      return sum + parseFloat(item.value.replace(/[$,]/g, ''));
    }, 0);

    return items.map(item => ({
      ...item,
      allocation: ((parseFloat(item.value.replace(/[$,]/g, '')) / total) * 100)
    }));
  };

  const handleUpdateProfile = (newName) => {
    setProfileName(newName);
  };

  const handleAddAsset = (newAsset) => {
    const updatedItems = [...portfolioItems, newAsset];
    const itemsWithAllocations = updatePortfolioAllocations(updatedItems);
    setPortfolioItems(itemsWithAllocations);
  };

  const navigationItems = [
    { name: 'DASHBOARD', key: 'DASHBOARD', icon: '📊' },
    { name: 'EXPENSES', key: 'EXPENSES', icon: '💸' },
    { name: 'PORTFOLIO', key: 'PORTFOLIO', icon: '📈' },
    { name: 'SETTINGS', key: 'SETTINGS', icon: '⚙️' }
  ];

  const renderContent = () => {
    switch (selectedTab) {
      case 'DASHBOARD':
      case 'PORTFOLIO':
        return (
          <DashboardPage
            portfolioItems={portfolioItems}
            profileName={profileName}
            onUpdatePortfolio={setPortfolioItems}
          />
        );
      case 'EXPENSES':
        return (
          <ExpensesPage
            portfolioItems={portfolioItems}
            onAddAsset={handleAddAsset}
            profileName={profileName}
          />
        );
      case 'SETTINGS':
        return (
          <SettingsPage
            profileName={profileName}
            onUpdateProfile={handleUpdateProfile}
          />
        );
      default:
        return (
          <DashboardPage
            portfolioItems={portfolioItems}
            profileName={profileName}
            onUpdatePortfolio={setPortfolioItems}
          />
        );
    }
  };

  return (
    <div className="w-full bg-[#233ea7] min-h-screen">
      <div className="w-full max-w-[1354px] mx-auto">
        <div className="flex flex-col lg:flex-row p-4 sm:p-6 gap-4 sm:gap-6">
          {/* Sidebar */}
          <div className="w-full lg:w-auto lg:min-w-[276px]">
            <div className="flex flex-col items-start gap-4 sm:gap-6">
              {/* Logo */}
              <div className="w-full flex justify-center lg:justify-start">
                <img 
                  src="/images/img_untitled_2_1.png" 
                  alt="FinanceFlow AI Logo" 
                  className="w-[104px] h-[104px] sm:w-[156px] sm:h-[156px] lg:w-[208px] lg:h-[208px]"
                />
              </div>
              
              {/* Navigation Menu */}
              <div className="flex flex-row lg:flex-col gap-4 sm:gap-6 lg:gap-8 w-full justify-center lg:justify-start">
                {navigationItems.map((item) => (
                  <button
                    key={item.key}
                    className={`text-[15px] sm:text-[20px] lg:text-[30px] font-poppins font-black leading-tight transition-colors duration-200 hover:text-global-3 flex items-center gap-2 ${
                      selectedTab === item.key ? 'text-global-3' : 'text-global-4'
                    }`}
                    onClick={() => setSelectedTab(item.key)}
                  >
                    <span className="text-lg lg:text-2xl">{item.icon}</span>
                    <span className="hidden sm:inline">{item.name}</span>
                  </button>
                ))}
              </div>

              {/* Profile Info */}
              <div className="hidden lg:block mt-8 p-4 bg-global-6 rounded-[16px] w-full">
                <div className="text-xs text-global-4 mb-1">Welcome back</div>
                <div className="text-sm font-poppins font-bold text-global-1">
                  {profileName}
                </div>
                <div className="text-xs text-global-4 mt-2">
                  Portfolio Value: ${portfolioItems.reduce((sum, item) => {
                    return sum + parseFloat(item.value.replace(/[$,]/g, ''));
                  }, 0).toLocaleString()}
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 bg-global-10 rounded-[24px] p-4 sm:p-6 lg:p-7 min-h-[calc(100vh-8rem)]">
            {renderContent()}
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className="lg:hidden fixed bottom-4 left-4 right-4 bg-global-6 rounded-[20px] p-2 shadow-lg z-50">
        <div className="flex justify-around items-center">
          {navigationItems.map((item) => (
            <button
              key={item.key}
              className={`flex flex-col items-center gap-1 py-2 px-3 rounded-lg transition-colors ${
                selectedTab === item.key ? 'bg-global-8 text-global-1' : 'text-global-4'
              }`}
              onClick={() => setSelectedTab(item.key)}
            >
              <span className="text-lg">{item.icon}</span>
              <span className="text-xs font-medium">{item.name}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MainApp;