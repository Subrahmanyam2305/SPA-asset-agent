import React, { useState } from 'react';
import ExpenseModal from '../../components/ui/ExpenseModal';
import AssetModal from '../../components/ui/AssetModal';

const ExpensesPage = ({ portfolioItems, onAddAsset, profileName }) => {
  const [expenses, setExpenses] = useState([
    { id: 1, title: 'Rent', amount: 1550, category: 'Rent', date: '2024-01-01', recurring: true, frequency: 'monthly' },
    { id: 2, title: 'Groceries', amount: 485, category: 'Food & Drinks', date: '2024-01-15' },
    { id: 3, title: 'Shopping', amount: 950, category: 'Shopping', date: '2024-01-10' },
    { id: 4, title: 'Gas', amount: 250, category: 'Transportation', date: '2024-01-12' },
    { id: 5, title: 'Investment Contribution', amount: 8500, category: 'Investments', date: '2024-01-01' },
    { id: 6, title: 'Car Payment', amount: 720, category: 'Vehicle', date: '2024-01-01', recurring: true },
    { id: 7, title: 'Utilities', amount: 200, category: 'Utilities', date: '2024-01-05', recurring: true },
    { id: 8, title: 'Charity Donation', amount: 50, category: 'Other', date: '2024-01-20' }
  ]);

  const [showExpenseModal, setShowExpenseModal] = useState(false);
  const [showAssetModal, setShowAssetModal] = useState(false);
  const [selectedView, setSelectedView] = useState('expenses'); // 'expenses' or 'assets'
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());

  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  // Calculate totals
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);

  // Group expenses by category
  const expensesByCategory = expenses.reduce((acc, expense) => {
    if (!acc[expense.category]) {
      acc[expense.category] = { total: 0, count: 0, items: [] };
    }
    acc[expense.category].total += expense.amount;
    acc[expense.category].count += 1;
    acc[expense.category].items.push(expense);
    return acc;
  }, {});

  const handleAddExpense = (newExpense) => {
    setExpenses(prev => [...prev, newExpense]);
  };

  const handleDeleteExpense = (expenseId) => {
    setExpenses(prev => prev.filter(e => e.id !== expenseId));
  };

  const getCategoryColor = (category) => {
    const colors = {
      'Rent': '#ff0004',
      'Food & Drinks': '#00abc9',
      'Shopping': '#ffe100',
      'Transportation': '#00d87a',
      'Vehicle': '#c900b2',
      'Investments': '#4800ff',
      'Utilities': '#ff6b00',
      'Healthcare': '#9c27b0',
      'Entertainment': '#00d87a',
      'Education': '#00abc9',
      'Insurance': '#ff0004',
      'Other': '#666666'
    };
    return colors[category] || '#666666';
  };

  const renderExpensesList = () => (
    <div className="space-y-4">
      {Object.entries(expensesByCategory).map(([category, data]) => (
        <div key={category} className="bg-global-6 rounded-[16px] p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <div 
                className="w-4 h-4 rounded-full"
                style={{ backgroundColor: getCategoryColor(category) }}
              ></div>
              <h3 className="text-[16px] font-poppins font-black text-global-1">
                {category}
              </h3>
              <span className="text-xs bg-global-10 px-2 py-1 rounded-full text-global-4">
                {data.count} item{data.count > 1 ? 's' : ''}
              </span>
            </div>
            <span className="text-[18px] font-poppins font-light text-global-1">
              ${data.total.toLocaleString()}
            </span>
          </div>

          <div className="space-y-2">
            {data.items.map((expense) => (
              <div key={expense.id} className="flex items-center justify-between bg-global-10 rounded-lg p-3">
                <div className="flex-1">
                  <div className="text-sm font-medium text-global-1">
                    {expense.title}
                  </div>
                  <div className="text-xs text-global-4">
                    {new Date(expense.date).toLocaleDateString()} 
                    {expense.recurring && (
                      <span className="ml-2 px-1 bg-global-6 rounded text-xs">
                        🔄 {expense.frequency}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-global-1">
                    ${expense.amount.toLocaleString()}
                  </span>
                  <button
                    onClick={() => handleDeleteExpense(expense.id)}
                    className="w-6 h-6 bg-[#ff0004]/20 text-[#ff0004] rounded-full flex items-center justify-center text-xs hover:bg-[#ff0004]/30 transition-colors"
                  >
                    ✕
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );

  const renderAssetsList = () => (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      {portfolioItems.map((asset) => (
        <div key={asset.id} className="bg-global-6 rounded-[16px] p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className={`w-[40px] h-[40px] ${asset.color} rounded-full`}></div>
            <div className="flex-1">
              <div className="text-[14px] font-poppins font-bold text-global-1">
                {asset.name}
              </div>
              <div className="text-xs text-global-4">
                {asset.category}
              </div>
            </div>
            {asset.indicator === 'up' && (
              <div className="text-[#00d87a] text-xs">↗</div>
            )}
            {asset.indicator === 'down' && (
              <div className="text-[#ff0004] text-xs">↘</div>
            )}
          </div>
          
          <div className="space-y-2">
            <div className="text-[16px] font-poppins font-light text-global-1">
              {asset.value}
            </div>
            <div className="text-xs text-global-4 bg-global-10 rounded-lg p-2">
              {asset.details}
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="flex flex-col gap-6 sm:gap-8">
      {/* Header */}
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <h1 className="text-[20px] sm:text-[24px] lg:text-[30px] font-poppins font-black text-global-1">
              {selectedView === 'expenses' ? 'EXPENSES & SPENDING' : 'ASSET MANAGEMENT'}
            </h1>
            <div className="text-xs text-global-4">
              {selectedView === 'expenses' ? 
                `${expenses.length} transactions • ${months[selectedMonth]} 2024` : 
                `${portfolioItems.length} assets in portfolio`
              }
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex bg-global-6 rounded-lg p-1">
              <button
                onClick={() => setSelectedView('expenses')}
                className={`px-3 py-1 rounded text-xs transition-colors ${
                  selectedView === 'expenses' ? 'bg-global-8 text-global-1' : 'text-global-4 hover:text-global-1'
                }`}
              >
                💸 Expenses
              </button>
              <button
                onClick={() => setSelectedView('assets')}
                className={`px-3 py-1 rounded text-xs transition-colors ${
                  selectedView === 'assets' ? 'bg-global-8 text-global-1' : 'text-global-4 hover:text-global-1'
                }`}
              >
                📈 Assets
              </button>
            </div>

            {selectedView === 'expenses' ? (
              <button
                onClick={() => setShowExpenseModal(true)}
                className="px-3 py-1 bg-global-8 text-global-1 rounded-lg text-xs hover:bg-opacity-90 transition-colors"
              >
                ➕ Add Expense
              </button>
            ) : (
              <button
                onClick={() => setShowAssetModal(true)}
                className="px-3 py-1 bg-global-8 text-global-1 rounded-lg text-xs hover:bg-opacity-90 transition-colors"
              >
                ➕ Add Asset
              </button>
            )}
          </div>
        </div>

        {/* Summary Stats */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          {selectedView === 'expenses' ? (
            <>
              <div className="flex flex-col">
                <span className="text-[36px] sm:text-[48px] lg:text-[72px] font-poppins font-light text-global-1">
                  ${totalExpenses.toLocaleString()}
                </span>
                <div className="text-sm text-global-4">
                  Total Monthly Expenses
                </div>
              </div>
              <div className="flex items-center gap-2">
                <select
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
                  className="bg-global-6 text-global-1 px-3 py-1 rounded-lg text-sm border-none focus:outline-none"
                >
                  {months.map((month, index) => (
                    <option key={index} value={index}>{month}</option>
                  ))}
                </select>
              </div>
            </>
          ) : (
            <div className="flex flex-col">
              <span className="text-[36px] sm:text-[48px] lg:text-[72px] font-poppins font-light text-global-1">
                {portfolioItems.length}
              </span>
              <div className="text-sm text-global-4">
                Total Assets in Portfolio
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          {selectedView === 'expenses' ? renderExpensesList() : renderAssetsList()}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {selectedView === 'expenses' ? (
            <div className="bg-global-6 rounded-[24px] p-5">
              <h3 className="text-[16px] font-poppins font-black text-global-1 mb-4">
                📊 Spending Breakdown
              </h3>
              
              <div className="space-y-3">
                {Object.entries(expensesByCategory).map(([category, data]) => {
                  const percentage = ((data.total / totalExpenses) * 100).toFixed(1);
                  return (
                    <div key={category} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-global-1">{category}</span>
                        <span className="text-global-4">{percentage}%</span>
                      </div>
                      <div className="w-full bg-global-10 rounded-full h-2">
                        <div 
                          className="h-full rounded-full"
                          style={{ 
                            width: `${percentage}%`,
                            backgroundColor: getCategoryColor(category)
                          }}
                        ></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="bg-global-6 rounded-[24px] p-5">
              <h3 className="text-[16px] font-poppins font-black text-global-1 mb-4">
                🏦 Quick Asset Stats
              </h3>
              
              <div className="space-y-3 text-xs">
                <div className="flex justify-between">
                  <span className="text-global-4">Most Valuable</span>
                  <span className="text-global-2">Real Estate</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-global-4">Best Performer</span>
                  <span className="text-global-2">Stocks</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-global-4">Categories</span>
                  <span className="text-global-1">{new Set(portfolioItems.map(item => item.category)).size}</span>
                </div>
              </div>
            </div>
          )}

          <div className="bg-global-6 rounded-[24px] p-5">
            <h3 className="text-[16px] font-poppins font-black text-global-1 mb-4">
              🎯 Quick Actions
            </h3>
            
            <div className="space-y-2">
              <button 
                onClick={() => setShowExpenseModal(true)}
                className="w-full text-left p-3 bg-global-10 rounded-lg text-sm text-global-1 hover:bg-global-8 hover:text-global-1 transition-colors"
              >
                💸 Log New Expense
              </button>
              <button 
                onClick={() => setShowAssetModal(true)}
                className="w-full text-left p-3 bg-global-10 rounded-lg text-sm text-global-1 hover:bg-global-8 hover:text-global-1 transition-colors"
              >
                📈 Add New Asset
              </button>
              <button className="w-full text-left p-3 bg-global-10 rounded-lg text-sm text-global-1 hover:bg-global-8 hover:text-global-1 transition-colors">
                📊 Generate Report
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      <ExpenseModal
        isOpen={showExpenseModal}
        onClose={() => setShowExpenseModal(false)}
        onSave={handleAddExpense}
      />

      <AssetModal
        isOpen={showAssetModal}
        onClose={() => setShowAssetModal(false)}
        onSave={onAddAsset}
      />
    </div>
  );
};

export default ExpensesPage;