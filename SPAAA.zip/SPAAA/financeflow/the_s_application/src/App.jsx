import MainApp from './pages/MainApp';

function App() {
  return (
    <MainApp />
  );
}

export default App;