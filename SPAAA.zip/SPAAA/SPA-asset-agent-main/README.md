# SPA-asset-agent
AI agent which analyzes your assets and flags potential risks based on multiple sources. 
