# FinanceFlow AI - Integrated Portfolio Management Platform

A sophisticated financial portfolio management system that combines the elegant **FinanceFlow** dashboard design with advanced **AI-powered asset analysis** from the SPA Asset Agent.

## 🚀 Features

### Frontend (React + Tailwind)
- **Comprehensive Portfolio**: View all asset types - Real Estate, Stocks, Crypto, Bonds, Collectibles, Vehicles, and more
- **Multiple Views**: Switch between grid and list layouts for optimal viewing
- **Profile Management**: Customizable user profile with name and preferences
- **Expense Management**: Track and categorize all expenses with recurring expense support
- **Asset Creation**: Add new assets to your portfolio with detailed information
- **Settings Panel**: Configure risk tolerance, notifications, and AI preferences
- **Mobile Responsive**: Fully optimized for desktop, tablet, and mobile devices
- **AI Integration**: Toggle between traditional view and AI-powered insights
- **Risk Assessment**: Color-coded risk indicators for each asset class

### Backend (Python + FastAPI + LangGraph)
- **AI Agents**: Multi-agent system for comprehensive asset analysis
- **Risk Assessment**: Automated risk scoring using LangGraph workflows
- **News Analysis**: Real-time market sentiment via Tavily integration
- **Financial Data**: Integration with yfinance and market data sources
- **RESTful API**: Clean API interface between frontend and AI services

## 🏗️ Architecture

```
┌─────────────────┐    HTTP/JSON     ┌──────────────────┐
│   React Frontend│◄────────────────►│  FastAPI Backend │
│                 │                  │                  │
│ • Portfolio UI  │                  │ • AI Agents      │
│ • Risk Alerts   │                  │ • Risk Analysis  │
│ • Asset Analysis│                  │ • Market Data    │
└─────────────────┘                  └──────────────────┘
                                               │
                                               ▼
                                    ┌──────────────────┐
                                    │   LangGraph      │
                                    │   AI Pipeline    │
                                    │                  │
                                    │ • Risk Assessor  │
                                    │ • News Analyzer  │
                                    │ • Report Generator│
                                    └──────────────────┘
```

## 🛠️ Quick Start

### Prerequisites
- Python 3.8+
- Node.js 16+
- npm or yarn

### Environment Setup
1. Create `.env` file in the `SPA-asset-agent-main` directory:
```env
OPENAI_API_KEY=your_openai_api_key
TAVILY_API_KEY=your_tavily_api_key
```

### Option 1: Automated Startup
```bash
# Make sure you're in the SPAA directory
cd /home/barracuda/spa/SPAA

# Run the integrated application
./start_integrated_app.sh
```

### Option 2: Manual Setup

#### Backend Setup
```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python main.py
```

#### Frontend Setup
```bash
cd financeflow/the_s_application
npm install
npm run start
```

## 📱 Usage

### Navigation
1. **Dashboard/Portfolio**: View comprehensive portfolio with all your assets
2. **Expenses**: Track spending, create new expenses, and manage assets
3. **Settings**: Configure profile, preferences, and AI settings

### Key Features
1. **Portfolio Management**:
   - View all 9+ asset categories in grid or list format
   - Toggle AI insights for advanced risk analysis
   - See real-time portfolio allocation and performance

2. **Expense Tracking**:
   - Log new expenses with categories and recurring options
   - View spending breakdown by category
   - Add new assets directly to your portfolio

3. **AI Stock Analysis Tool** (ENHANCED!):
   - Click "📈 Stock Analysis" to open the comprehensive stock analyzer
   - **Two Analysis Modes**:
     - **🔍 Stock Search**: Analyze any individual stock (AAPL, GOOGL, TSLA, etc.)
     - **📊 Live Portfolio**: View all your portfolio stocks with risk assessments
   - Get AI-powered technical, fundamental, and sentiment analysis
   - View real-time risk levels for your entire portfolio
   - Refresh individual stock analysis with latest data
   - See detailed risk explanations from your portfolio API

4. **AI Features**:
   - Click "🤖 AI Insights" to enable advanced analysis
   - Get real-time risk assessments for each asset
   - Monitor AI alerts and recommendations

4. **Profile Settings**:
   - Change your display name
   - Set risk tolerance and preferences
   - Configure notification settings

## 🤖 AI Components

### Asset Analysis
- Individual asset risk assessment
- Market sentiment analysis  
- Confidence scoring
- Actionable recommendations

### Portfolio Analysis
- Overall portfolio risk calculation
- Asset correlation analysis
- Diversification recommendations
- Alert generation

### Risk Alerts
- Real-time market monitoring
- Risk threshold notifications
- Opportunity identification
- System status indicators

### 🆕 AI Stock Analysis Tool
- **Comprehensive Stock Analysis**: Technical, fundamental, and sentiment analysis in one tool
- **Real-time Data**: Live stock prices, volume, and market metrics
- **AI Recommendations**: Buy/Hold/Sell recommendations with confidence scores
- **Technical Indicators**: RSI, MACD, trend analysis, support/resistance
- **Fundamental Metrics**: P/E ratio, market cap, dividend yield, beta, ROE
- **Sentiment Tracking**: Analyst ratings, news sentiment, social media buzz
- **Stock Screener**: Popular stocks and sector-based filtering
- **Watchlist Management**: Add stocks to personal watchlist

## 🔧 API Endpoints

### Core Endpoints
- `POST /analyze/asset` - Analyze individual asset
- `POST /analyze/portfolio` - Analyze entire portfolio  
- `GET /portfolio/alerts` - Get current alerts
- `GET /health` - Service health check
- `GET /docs` - Interactive API documentation

### 📈 Stock Analysis Endpoints
- `POST /analyze/stock` - Comprehensive AI stock analysis
- `GET /stocks/quote/{symbol}` - Real-time stock quote
- `GET /stocks/trending` - Get trending stocks
- `GET /stocks/watchlist/{user_id}` - User's stock watchlist
- `POST /stocks/watchlist/{user_id}` - Add stock to watchlist

### Example Request
```javascript
fetch('http://localhost:8000/analyze/asset', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    asset_name: 'Real Estate',
    asset_type: 'real_estate',
    current_value: 680550
  })
})
```

## 🎨 UI Components

### Main Pages
- `MainApp` - Central navigation and state management
- `DashboardPage` - Comprehensive portfolio dashboard with grid/list views
- `ExpensesPage` - Expense tracking and asset management
- `SettingsPage` - Profile and system configuration

### UI Components
- `RiskAlerts.jsx` - Real-time AI risk monitoring panel
- `AssetAnalysis.jsx` - Individual asset AI analysis with expandable details
- `ExpenseModal.jsx` - Modal for creating new expenses
- `AssetModal.jsx` - Modal for adding new portfolio assets
- `aiAnalysisService.js` - Backend integration service

### Features
- **9+ Asset Categories**: Real Estate, Stocks, Crypto, Bonds, Collectibles, Vehicles, Cash, Commodities, Art
- **Dynamic Allocation**: Real-time portfolio percentage calculations
- **Responsive Design**: Mobile-first approach with desktop enhancements
- **AI Integration**: Seamless toggle between standard and AI-enhanced views

## 🔒 Security & Privacy

- **Defensive Security**: Code designed for asset protection and risk analysis
- **API Security**: CORS-enabled with configurable origins
- **Data Privacy**: No sensitive data logged or persisted
- **Error Handling**: Graceful fallbacks when AI services unavailable

## 🚧 Development

### Adding New AI Agents
1. Create agent in `SPA-asset-agent-main/agentic_pipeline.py`
2. Add endpoint in `backend/main.py`
3. Create React component in `src/components/ui/`
4. Integrate with dashboard

### Customizing Risk Models
- Modify risk assessment logic in `agentic_pipeline.py`
- Update risk color mappings in `aiAnalysisService.js`
- Adjust confidence thresholds as needed

## 📊 Performance

- **Frontend**: React with Vite for fast development
- **Backend**: Async FastAPI with thread pool execution
- **AI Processing**: Cached results to minimize API calls
- **Real-time**: 30-second alert refresh intervals

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`) 
5. Open Pull Request

## 📄 License

This project combines components under different licenses:
- FinanceFlow frontend: Original project license
- SPA Asset Agent: MIT License
- Integration code: MIT License

## 🆘 Troubleshooting

### Common Issues

**AI Service Unavailable**
- Check `.env` file configuration
- Verify API keys are valid
- Ensure backend is running on port 8000

**Frontend Connection Issues**
- Confirm backend is accessible
- Check CORS configuration
- Verify ports 5173 and 8000 are available

**Module Import Errors**
- Ensure Python path includes SPA-asset-agent-main
- Check virtual environment activation
- Verify all dependencies installed

---

**Built with ❤️ combining elegant design with powerful AI**