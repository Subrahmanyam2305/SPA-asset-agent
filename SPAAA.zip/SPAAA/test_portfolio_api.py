#!/usr/bin/env python3
"""
Test script to verify portfolio API integration works correctly.
Run this to test the connection to the ngrok portfolio API.
"""

import requests
import json
import asyncio
import httpx

PORTFOLIO_API_URL = "https://72b0804082dd.ngrok-free.app"
LOCAL_API_URL = "http://localhost:8000"

async def test_direct_portfolio_api():
    """Test direct connection to the portfolio API"""
    print("🧪 Testing direct connection to portfolio API...")
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{PORTFOLIO_API_URL}/portfolio",
                headers={"ngrok-skip-browser-warning": "true"}
            )
            
            if response.status_code == 200:
                data = response.json()
                print("✅ Direct API connection successful!")
                print(f"📊 Found {len(data.get('portfolio', []))} stocks in portfolio:")
                
                for stock in data.get('portfolio', [])[:3]:  # Show first 3
                    print(f"  • {stock['name'].title()} - Risk: {stock['risks']}")
                
                if len(data.get('portfolio', [])) > 3:
                    print(f"  ... and {len(data.get('portfolio', [])) - 3} more stocks")
                    
                return True
            else:
                print(f"❌ API returned status code: {response.status_code}")
                return False
                
    except Exception as e:
        print(f"❌ Direct API connection failed: {e}")
        return False

def test_local_backend():
    """Test local backend portfolio endpoints"""
    print("\n🧪 Testing local backend portfolio endpoints...")
    
    try:
        # Test health check first
        response = requests.get(f"{LOCAL_API_URL}/health")
        if response.status_code != 200:
            print("❌ Local backend not running. Please start it first.")
            return False
        
        print("✅ Local backend is running")
        
        # Test portfolio live endpoint
        response = requests.get(f"{LOCAL_API_URL}/portfolio/live")
        if response.status_code == 200:
            data = response.json()
            print("✅ Portfolio live endpoint working!")
            print(f"📊 Retrieved {len(data.get('portfolio', []))} stocks")
        else:
            print(f"❌ Portfolio live endpoint failed: {response.status_code}")
            return False
        
        # Test portfolio stocks analysis endpoint
        response = requests.get(f"{LOCAL_API_URL}/analyze/portfolio-stocks")
        if response.status_code == 200:
            stocks = response.json()
            print("✅ Portfolio stocks analysis endpoint working!")
            print(f"📈 Analyzed {len(stocks)} stocks:")
            
            for stock in stocks[:3]:
                print(f"  • {stock['name']} ({stock['symbol']}) - Risk: {stock['risk_level']}")
            
            if len(stocks) > 3:
                print(f"  ... and {len(stocks) - 3} more stocks")
                
            return True
        else:
            print(f"❌ Portfolio stocks analysis failed: {response.status_code}")
            return False
            
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to local backend. Make sure it's running on port 8000.")
        return False
    except Exception as e:
        print(f"❌ Local backend test failed: {e}")
        return False

async def main():
    print("🚀 Portfolio API Integration Test")
    print("=" * 50)
    
    # Test direct API connection
    api_works = await test_direct_portfolio_api()
    
    # Test local backend
    backend_works = test_local_backend()
    
    print("\n📋 Test Results:")
    print(f"Direct Portfolio API: {'✅ Working' if api_works else '❌ Failed'}")
    print(f"Local Backend Proxy: {'✅ Working' if backend_works else '❌ Failed'}")
    
    if api_works and backend_works:
        print("\n🎉 All tests passed! The portfolio integration is ready to use.")
        print("\n💡 Next steps:")
        print("1. Start the integrated app: ./start_integrated_app.sh")
        print("2. Go to http://localhost:5173")
        print("3. Click '📈 Stock Analysis' in the portfolio dashboard")
        print("4. Switch to the '📊 Live Portfolio Analysis' tab")
    else:
        print("\n⚠️  Some tests failed. Please check the connections.")

if __name__ == "__main__":
    asyncio.run(main())