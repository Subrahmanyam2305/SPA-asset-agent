from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import sys
import os
import json
import asyncio
from concurrent.futures import ThreadPoolExecutor
import traceback

# Add the SPA-asset-agent-main directory to Python path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'SPA-asset-agent-main'))

try:
    import agentic_pipeline
    import src_base
    from src_base import Asset
    import src_sixtyfour as sixtyfour
    import mixrank_data as mixrank
    from dataclasses import asdict
    import dacite
except ImportError as e:
    print(f"Warning: Could not import AI modules: {e}")
    # Create mock classes for development
    class Asset:
        def __init__(self, name, data=None):
            self.name = name
            self.data = data
    
    class RiskLevel:
        HIGH = "high"
        MEDIUM = "medium"
        LOW = "low"
        VERY_LOW = "very_low"
        ABSENT = "absent"

app = FastAPI(title="FinanceFlow AI Backend", version="1.0.0")

# Configure CORS for React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request/Response models
class AssetAnalysisRequest(BaseModel):
    asset_name: str
    asset_type: str
    current_value: float

class RiskAssessment(BaseModel):
    risk_level: str
    confidence: int
    reasoning: str
    timestamp: str

class AssetInsight(BaseModel):
    asset_name: str
    risk_assessment: RiskAssessment
    market_data: Optional[Dict[str, Any]] = None
    news_sentiment: Optional[str] = None
    recommendations: List[str] = []

class StockAnalysisRequest(BaseModel):
    symbol: str
    analysis_type: str = "comprehensive"  # comprehensive, technical, fundamental

class TechnicalIndicators(BaseModel):
    rsi: float
    macd_signal: str
    trend: str
    support_level: float
    resistance_level: float
    volume_analysis: str

class FundamentalData(BaseModel):
    pe_ratio: float
    market_cap: str
    dividend_yield: float
    beta: float
    roe: str
    profit_margin: str
    debt_to_equity: float
    valuation: str

class StockSentiment(BaseModel):
    analyst_rating: str
    price_target: float
    news_sentiment: str
    social_sentiment_score: int

class ComprehensiveStockAnalysis(BaseModel):
    symbol: str
    company_name: str
    current_price: float
    price_change: float
    price_change_percent: float
    volume: int
    technical_analysis: TechnicalIndicators
    fundamental_analysis: FundamentalData
    sentiment_analysis: StockSentiment
    ai_recommendation: str
    risk_level: str
    confidence_score: int

class PortfolioAnalysis(BaseModel):
    total_value: float
    overall_risk: str
    asset_insights: List[AssetInsight]
    alerts: List[str] = []

# In-memory storage for demo purposes
portfolio_cache: Dict[str, Any] = {}
analysis_cache: Dict[str, AssetInsight] = {}

@app.get("/")
async def root():
    return {"message": "FinanceFlow AI Backend API", "status": "active"}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "ai_modules_loaded": "agentic_pipeline" in sys.modules}

@app.post("/analyze/asset", response_model=AssetInsight)
async def analyze_asset(request: AssetAnalysisRequest):
    """Analyze a single asset using the AI agent pipeline"""
    try:
        # Create asset instance
        asset = Asset(request.asset_name, None)
        
        # Check cache first
        cache_key = f"{request.asset_name}_{request.asset_type}"
        if cache_key in analysis_cache:
            return analysis_cache[cache_key]
        
        # Run analysis in thread pool to avoid blocking
        loop = asyncio.get_event_loop()
        with ThreadPoolExecutor(max_workers=2) as executor:
            try:
                # Load sources
                sources = [
                    sixtyfour.SixtyFourResearchSource(),
                    mixrank.MixRank(),
                ] if 'sixtyfour' in sys.modules else []
                
                if sources:
                    # Build and run pipeline
                    graph = agentic_pipeline.build_pipeline(asset)
                    
                    # Get research data
                    insight = sources[0].research_asset_update(asset) if sources else None
                    
                    if insight:
                        user_input = (
                            f"Please analyze the following data set to assess potential risks for {asset.name}.\n\n"
                            f"{json.dumps(asdict(insight))}"
                        )
                        
                        result_str = await loop.run_in_executor(
                            executor, 
                            lambda: agentic_pipeline.stream_graph_updates(graph, user_input)
                        )
                        
                        # Parse result
                        result = dacite.from_dict(agentic_pipeline.ReporterOutput, json.loads(result_str))
                        
                        # Create response
                        risk_assessment = RiskAssessment(
                            risk_level=result.risk_level.value,
                            confidence=85,  # Mock confidence
                            reasoning=result.report,
                            timestamp=str(asyncio.get_event_loop().time())
                        )
                    else:
                        # Fallback analysis
                        risk_assessment = RiskAssessment(
                            risk_level="medium",
                            confidence=70,
                            reasoning=f"Limited data available for {request.asset_name}. Moderate risk assumed.",
                            timestamp=str(asyncio.get_event_loop().time())
                        )
                else:
                    # Mock analysis when AI modules not available
                    risk_assessment = RiskAssessment(
                        risk_level="low",
                        confidence=75,
                        reasoning=f"Mock analysis for {request.asset_name}: Stable asset with moderate growth potential.",
                        timestamp=str(asyncio.get_event_loop().time())
                    )
                
                # Create asset insight
                asset_insight = AssetInsight(
                    asset_name=request.asset_name,
                    risk_assessment=risk_assessment,
                    market_data={
                        "current_value": request.current_value,
                        "asset_type": request.asset_type,
                        "last_updated": str(asyncio.get_event_loop().time())
                    },
                    recommendations=[
                        f"Monitor {request.asset_name} for market changes",
                        "Consider diversification based on risk level",
                        "Review position size relative to portfolio"
                    ]
                )
                
                # Cache result
                analysis_cache[cache_key] = asset_insight
                
                return asset_insight
                
            except Exception as e:
                print(f"Error in AI analysis: {e}")
                traceback.print_exc()
                # Return fallback analysis
                return AssetInsight(
                    asset_name=request.asset_name,
                    risk_assessment=RiskAssessment(
                        risk_level="medium",
                        confidence=50,
                        reasoning=f"Analysis unavailable due to technical issues. Default risk assessment applied.",
                        timestamp=str(asyncio.get_event_loop().time())
                    ),
                    recommendations=["Technical analysis temporarily unavailable"]
                )
                
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")

@app.post("/analyze/portfolio", response_model=PortfolioAnalysis)
async def analyze_portfolio(assets: List[AssetAnalysisRequest]):
    """Analyze entire portfolio"""
    try:
        # Analyze each asset
        asset_insights = []
        total_value = 0
        high_risk_count = 0
        
        for asset_request in assets:
            insight = await analyze_asset(asset_request)
            asset_insights.append(insight)
            total_value += asset_request.current_value
            
            if insight.risk_assessment.risk_level in ["high", "medium"]:
                high_risk_count += 1
        
        # Calculate overall portfolio risk
        risk_ratio = high_risk_count / len(assets) if assets else 0
        if risk_ratio > 0.6:
            overall_risk = "high"
        elif risk_ratio > 0.3:
            overall_risk = "medium"
        else:
            overall_risk = "low"
        
        # Generate alerts
        alerts = []
        if high_risk_count > 0:
            alerts.append(f"{high_risk_count} assets showing elevated risk levels")
        if risk_ratio > 0.5:
            alerts.append("Portfolio concentration risk detected")
        
        return PortfolioAnalysis(
            total_value=total_value,
            overall_risk=overall_risk,
            asset_insights=asset_insights,
            alerts=alerts
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Portfolio analysis failed: {str(e)}")

@app.get("/portfolio/alerts")
async def get_portfolio_alerts():
    """Get current portfolio alerts"""
    return {
        "alerts": [
            {
                "type": "risk",
                "message": "High volatility detected in cryptocurrency positions",
                "severity": "medium",
                "timestamp": str(asyncio.get_event_loop().time())
            },
            {
                "type": "opportunity",
                "message": "Real estate sector showing strong fundamentals",
                "severity": "info",
                "timestamp": str(asyncio.get_event_loop().time())
            }
        ]
    }

@app.post("/analyze/stock", response_model=ComprehensiveStockAnalysis)
async def analyze_stock(request: StockAnalysisRequest):
    """Comprehensive AI-powered stock analysis"""
    try:
        symbol = request.symbol.upper()
        
        # In production, integrate with yfinance or financial data API
        # For now, using mock data with realistic patterns
        import random
        import time
        
        # Mock current market data
        base_price = random.uniform(50, 300)
        price_change = random.uniform(-10, 10)
        price_change_percent = (price_change / base_price) * 100
        
        # Generate realistic technical indicators
        rsi = random.uniform(20, 80)
        macd_signal = "BUY" if price_change > 0 else "SELL" if price_change < -2 else "HOLD"
        trend = "BULLISH" if price_change > 2 else "BEARISH" if price_change < -2 else "SIDEWAYS"
        
        # Mock fundamental data
        pe_ratio = random.uniform(10, 35)
        market_cap_billion = random.uniform(10, 1000)
        market_cap = f"{market_cap_billion:.1f}B"
        
        # AI-powered risk assessment
        if pe_ratio > 30 or rsi > 70:
            risk_level = "HIGH"
            ai_recommendation = "HOLD or REDUCE position due to overvaluation signals"
        elif pe_ratio < 15 and rsi < 30:
            risk_level = "LOW"
            ai_recommendation = "STRONG BUY opportunity detected - undervalued with good technicals"
        else:
            risk_level = "MEDIUM"
            ai_recommendation = "MODERATE BUY - balanced risk/reward profile"
        
        # Company name mapping (in production, would fetch from API)
        company_names = {
            "AAPL": "Apple Inc.",
            "GOOGL": "Alphabet Inc.",
            "MSFT": "Microsoft Corporation",
            "TSLA": "Tesla Inc.",
            "NVDA": "NVIDIA Corporation",
            "AMZN": "Amazon.com Inc.",
            "META": "Meta Platforms Inc.",
            "JPM": "JPMorgan Chase & Co.",
            "JNJ": "Johnson & Johnson",
            "V": "Visa Inc."
        }
        
        analysis = ComprehensiveStockAnalysis(
            symbol=symbol,
            company_name=company_names.get(symbol, f"{symbol} Corporation"),
            current_price=round(base_price, 2),
            price_change=round(price_change, 2),
            price_change_percent=round(price_change_percent, 2),
            volume=random.randint(1000000, 50000000),
            technical_analysis=TechnicalIndicators(
                rsi=round(rsi, 1),
                macd_signal=macd_signal,
                trend=trend,
                support_level=round(base_price * 0.95, 2),
                resistance_level=round(base_price * 1.05, 2),
                volume_analysis="HIGH" if random.random() > 0.5 else "NORMAL"
            ),
            fundamental_analysis=FundamentalData(
                pe_ratio=round(pe_ratio, 1),
                market_cap=market_cap,
                dividend_yield=round(random.uniform(0, 4), 2),
                beta=round(random.uniform(0.5, 2.0), 2),
                roe=f"{random.uniform(10, 25):.1f}%",
                profit_margin=f"{random.uniform(5, 30):.1f}%",
                debt_to_equity=round(random.uniform(0.1, 2.0), 2),
                valuation="UNDERVALUED" if pe_ratio < 20 else "OVERVALUED" if pe_ratio > 25 else "FAIR"
            ),
            sentiment_analysis=StockSentiment(
                analyst_rating=["STRONG BUY", "BUY", "HOLD", "SELL"][random.randint(0, 3)],
                price_target=round(base_price * random.uniform(0.9, 1.2), 2),
                news_sentiment=["POSITIVE", "NEUTRAL", "NEGATIVE"][random.randint(0, 2)],
                social_sentiment_score=random.randint(60, 95)
            ),
            ai_recommendation=ai_recommendation,
            risk_level=risk_level,
            confidence_score=random.randint(75, 95)
        )
        
        return analysis
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Stock analysis failed: {str(e)}")

@app.get("/stocks/trending")
async def get_trending_stocks():
    """Get trending stocks with basic info"""
    trending = [
        {"symbol": "AAPL", "name": "Apple Inc.", "change": 2.5, "volume": "high"},
        {"symbol": "TSLA", "name": "Tesla Inc.", "change": -1.2, "volume": "high"},
        {"symbol": "NVDA", "name": "NVIDIA Corp.", "change": 5.8, "volume": "very_high"},
        {"symbol": "GOOGL", "name": "Alphabet Inc.", "change": 1.1, "volume": "normal"},
        {"symbol": "MSFT", "name": "Microsoft Corp.", "change": 0.8, "volume": "normal"},
    ]
    return {"trending_stocks": trending}

@app.get("/stocks/watchlist/{user_id}")
async def get_user_watchlist(user_id: str):
    """Get user's stock watchlist"""
    # Mock watchlist - in production, would fetch from database
    watchlist = ["AAPL", "GOOGL", "MSFT", "TSLA", "NVDA"]
    return {"watchlist": watchlist}

@app.post("/stocks/watchlist/{user_id}")
async def add_to_watchlist(user_id: str, symbol: str):
    """Add stock to user's watchlist"""
    # Mock implementation - in production, would save to database
    return {"message": f"Added {symbol} to watchlist for user {user_id}", "success": True}

# Additional endpoint for real-time stock quotes (mock)
@app.get("/stocks/quote/{symbol}")
async def get_stock_quote(symbol: str):
    """Get real-time stock quote"""
    # Mock real-time data - in production, integrate with financial data provider
    import random
    import time
    
    base_price = random.uniform(50, 300)
    return {
        "symbol": symbol.upper(),
        "price": round(base_price, 2),
        "change": round(random.uniform(-5, 5), 2),
        "change_percent": round(random.uniform(-3, 3), 2),
        "volume": random.randint(1000000, 20000000),
        "last_updated": time.time()
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)