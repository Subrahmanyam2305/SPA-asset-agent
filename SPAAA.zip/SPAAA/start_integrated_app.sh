#!/bin/bash

# FinanceFlow + AI Agent Integration Startup Script

echo "🚀 Starting FinanceFlow with AI Asset Analysis Integration"
echo "=============================================="

# Set environment variables
export PYTHONPATH="${PYTHONPATH}:$(pwd)/SPA-asset-agent-main"

# Check if Python dependencies are installed
if [ ! -d "backend/venv" ]; then
    echo "📦 Setting up Python virtual environment..."
    cd backend
    python3 -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt
    cd ..
fi

# Check if Node dependencies are installed
if [ ! -d "financeflow/the_s_application/node_modules" ]; then
    echo "📦 Installing Node.js dependencies..."
    cd financeflow/the_s_application
    npm install
    cd ../..
fi

# Start the backend API server in background
echo "🐍 Starting Python AI Backend on port 8000..."
cd backend
source venv/bin/activate
python main.py &
BACKEND_PID=$!
cd ..

# Wait for backend to start
echo "⏳ Waiting for backend to initialize..."
sleep 5

# Start the React frontend
echo "⚛️ Starting React Frontend on port 5173..."
cd financeflow/the_s_application
npm run start &
FRONTEND_PID=$!

echo ""
echo "🎆 FinanceFlow AI Integration Complete!"
echo "Frontend: http://localhost:5173"
echo "Backend API: http://localhost:8000"
echo "API Docs: http://localhost:8000/docs"
echo ""
echo "📊 Enhanced Features:"
echo "  ✅ Complete portfolio dashboard with all asset types"
echo "  ✅ Real Estate, Stocks, Crypto, Bonds, Collectibles, etc."
echo "  ✅ AI-powered risk assessment and insights"
echo "  ✅ Expense tracking and management"
echo "  ✅ Asset creation and portfolio management"
echo "  ✅ Profile settings and customization"
echo "  ✅ Grid and list view options"
echo "  ✅ Mobile responsive design"
echo ""
echo "🤖 AI Features:"
echo "  - LangGraph multi-agent analysis"
echo "  - Real-time risk scoring"
echo "  - Market sentiment analysis"
echo "  - Portfolio optimization alerts"
echo "  - 🆕 Live Portfolio Stock Analysis"
echo "  - Integration with external portfolio API"
echo "  - Individual stock risk assessments"
echo ""
echo "Press Ctrl+C to stop both services"

# Function to cleanup on exit
cleanup() {
    echo ""
    echo "🛑 Shutting down services..."
    kill $BACKEND_PID 2>/dev/null
    kill $FRONTEND_PID 2>/dev/null
    echo "✅ Services stopped"
    exit 0
}

# Trap Ctrl+C and call cleanup
trap cleanup INT

# Wait for both processes
wait $BACKEND_PID $FRONTEND_PID